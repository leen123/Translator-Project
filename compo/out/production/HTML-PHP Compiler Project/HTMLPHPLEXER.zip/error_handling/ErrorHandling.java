package error_handling;

import java.util.ArrayList;
import java.util.List;

public class ErrorHandling {
    public static List<String> error = new ArrayList<>();
    public static List<String> errorLogic = new ArrayList<>();
    public static List<String> errorFile = new ArrayList<>();
    public static List<String> errorLogicFile = new ArrayList<>();
}
