package ast;

import ast.Controller.DefinedController;
import ast.Page.DefinedPage;
import error_handling.ErrorHandling;
import symbol_table.Row;
import symbol_table.SymbolTable;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class App {
    List<DefinedController> definedControllers;
    List<DefinedPage> pages;
    public App(){
        this.definedControllers = new LinkedList<>();
        this.pages = new LinkedList<>();
    }
    public void addController(DefinedController definedController){
        this.definedControllers.add(definedController);
    }
    public void addPage(DefinedPage page){
        this.pages.add(page);
    }
    public void debug(){
        boolean error =false;
        //pages
        for (DefinedPage page:pages) {
            if(SymbolTable.checkFound(page.getPageId(),"","").size()>0){
                ErrorHandling.error.add("[a name '"+page.getPageId()+"' is already found]: can't define the page by that name");
                error=true;
            }else {
                SymbolTable.table.put(page.getPageId(),
                        new Row("pageId","global", Arrays.asList(new String[]{page.getPageId()})));
            }
        }
        //controllers
        for (DefinedController controller:definedControllers) {
            //ControllerId
            if(SymbolTable.checkFound(controller.getControllerId(),"","").size()>0){
                ErrorHandling.error.add("[a name '"+controller.getControllerId()+"' is already found]: can't define the controller by that name");
                error=true;
            }else {
                SymbolTable.table.put(controller.getControllerId(),
                        new Row("controllerId","global", Arrays.asList(new String[]{controller.getControllerId()})));
            }

        }
        if (error) return;
        //pages
        for (DefinedPage page:pages) {
            page.debug();
        }
        if (SymbolTable.stop) return;
        //controllers
        for (DefinedController controller:definedControllers) {

            controller.debug();
        }
        if (SymbolTable.stop) return;

    }
}
