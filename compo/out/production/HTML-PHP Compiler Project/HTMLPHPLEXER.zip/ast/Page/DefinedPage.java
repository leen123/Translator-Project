package ast.Page;

import color.Colors;
import error_handling.ErrorHandling;
import symbol_table.Row;
import symbol_table.SymbolTable;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class DefinedPage {
    private String pageAttribute;
    private String pageId;
    private String extendedPageId;
    private List<Body> bodies;
    private Location SubmitLocation;

    public Location getSubmitLocation() {
        return SubmitLocation;
    }

    public void setSubmitLocation(Location submitLocation) {
        SubmitLocation = submitLocation;
    }

    public DefinedPage(){
        this.bodies = new LinkedList<>();
    }
    public String getPageAttribute() {
        return pageAttribute;
    }

    public void setPageAttribute(String pageAttribute) {
        this.pageAttribute = pageAttribute;
    }

    public String getPageId() {
        return pageId;
    }

    public void setPageId(String pageId) {
        this.pageId = pageId;
    }

    public void addBody(Body body){
        this.bodies.add(body);
    }

    public String getExtendedPageId() {
        return extendedPageId;
    }

    public void setExtendedPageId(String extendedPageId) {
        this.extendedPageId = extendedPageId;
    }

    public List<Body> getBodies() {
        return bodies;
    }

    public void setBodies(List<Body> bodies) {
        this.bodies = bodies;
    }
    public void debug(){
        //extendedPageId found
        if(extendedPageId!=null){
            if(SymbolTable.checkFound(extendedPageId,"pageId","").size()>0){
                if(!extendedPageId.equals(pageId)){
                    SymbolTable.table.get(extendedPageId).table.put(pageId,
                            new Row("extendedPageId","page", Arrays.asList(new String[]{extendedPageId,pageId})));
                }else{
                    ErrorHandling.error.add(Colors.TEXT_B+Colors.TEXT_RED+"[a name '"+extendedPageId+"' is same name pageId '"+pageId+"']:"+Colors.TEXT_RESET+Colors.TEXT_RED+" can't define the extendedPageId by that name"
                            + Colors.TEXT_YELLOW+ ", path: '"+SymbolTable.formatPath(Arrays.asList(new String[]{extendedPageId,pageId}))+"'"+Colors.TEXT_RESET);
                    SymbolTable.stop=true;
                }
            }else {
                ErrorHandling.error.add(Colors.TEXT_B+Colors.TEXT_RED+"[a name '"+extendedPageId+"' is not found]:"+Colors.TEXT_RESET+Colors.TEXT_RED+" can't define the extendedPageId by that name"
                        + Colors.TEXT_YELLOW+ ", path: '"+SymbolTable.formatPath(Arrays.asList(new String[]{extendedPageId,pageId}))+"'"+Colors.TEXT_RESET);
                SymbolTable.stop=true;
            }
        }

        if (SymbolTable.stop) return;
        for (Body body:bodies) {
            body.debug(Arrays.asList(new String[]{pageId}),"page");
            if (SymbolTable.stop) return;
        }
        //controller.debug(Arrays.asList(new String[]{controllerId}));

    }
}
