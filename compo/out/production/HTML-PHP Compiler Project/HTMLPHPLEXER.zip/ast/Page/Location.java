package ast.Page;

import java.util.List;

public class Location {
    private String location;
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
