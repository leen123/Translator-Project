package ast.Page.Output;

import symbol_table.Row;
import symbol_table.SymbolTable;

import java.util.ArrayList;
import java.util.List;

public class OutputText {
    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    private String text;
    public void debug(List key, String scope){
        List tempPath= new ArrayList();
        tempPath.addAll(key);
        tempPath.add(text);
        Row row= SymbolTable.findRow(key);
        row.table.put(text,
                new Row("text","var","page", tempPath));
    }

}
