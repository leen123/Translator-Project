package ast.Page.Input.FieldType;

public class Integer  {
    private java.lang.Integer number;

    public java.lang.Integer getNumber() {
        return number;
    }

    public void setNumber(java.lang.Integer number) {
        this.number = number;
    }
}
