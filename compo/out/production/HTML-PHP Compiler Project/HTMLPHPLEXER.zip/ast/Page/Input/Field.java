package ast.Page.Input;

import ast.Page.Input.FieldType.InputText;
import color.Colors;
import error_handling.ErrorHandling;
import symbol_table.Row;
import symbol_table.SymbolTable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Field  {
    String inputText;

    public String getInputText() {
        return inputText;
    }

    public void setInputText(String inputText) {
        this.inputText = inputText;
    }
    public void debug(List key, String scope){
        List path= new ArrayList();
        path.addAll(key);
        path.add(inputText);
       if(SymbolTable.checkFound(inputText,"","global").size()<=0){
           Row row=SymbolTable.findRow(key);
           if(SymbolTable.checkFound(row.table,inputText,"","").size()<=0){
               row.table.put(inputText,
                       new Row("field","page", path));

           }else {
               ErrorHandling.error.add(Colors.TEXT_B+Colors.TEXT_RED+"[a name '"+inputText+"' is found in this scope'"+scope+"']:"+Colors.TEXT_RESET+Colors.TEXT_RED+" can't define the inputText by that name"
                       + Colors.TEXT_YELLOW+ ", path: '"+SymbolTable.formatPath(path)+"'"+Colors.TEXT_RESET);
               SymbolTable.stop=true;
           }
       }else {
           ErrorHandling.error.add(Colors.TEXT_B+Colors.TEXT_RED+"[a name '"+inputText+"' is found in the scope'"+scope+"']:"+Colors.TEXT_RESET+Colors.TEXT_RED+" can't define the inputText by that name"
                   + Colors.TEXT_YELLOW+ ", path: '"+SymbolTable.formatPath(path)+"'"+Colors.TEXT_RESET);
           SymbolTable.stop=true;
       }
    }
}
