package ast.Page.Input.MultipleChoice;


import ast.Page.Input.Field;
import ast.Page.Input.FieldType.InputText;
import ast.Page.Input.Input;
import color.Colors;
import error_handling.ErrorHandling;
import symbol_table.Row;
import symbol_table.SymbolTable;

import java.util.ArrayList;
import java.util.List;

public class Radio extends MultipleChoice {
    InputText firstInputText;
    InputText secondInputText;
    private String Key;

    public String getKey() {
        return Key;
    }

    public void setKey(String key) {
        Key = key;
    }

    public InputText getFirstFieldType() {
        return this.secondInputText;
    }

    public void setFirstInputText(InputText firstInputText) {
        this.firstInputText = firstInputText;
    }

    public InputText getSecondFieldType() {
        return this.secondInputText;
    }

    public void setSecondInputText(InputText secondInputText) {
        this.secondInputText = secondInputText;
    }

    public void debug(List key, String scope){
        List tempPath= new ArrayList();
        tempPath.addAll(key);
        tempPath.add(Key);
        if(SymbolTable.checkFound(Key,"","global").size()<=0){
            Row row=SymbolTable.findRow(key);
            if(SymbolTable.checkFound(row.table,Key,"","").size()<=0){
                row.table.put(Key.toString(),
                        new Row("radio","page", tempPath));
                firstInputText.debug(tempPath,"radio");
                secondInputText.debug(tempPath,"radio");

            }else {
                ErrorHandling.error.add(Colors.TEXT_B+Colors.TEXT_RED+"[a name '"+Key+"' is found in this scope'"+scope+"']:"+Colors.TEXT_RESET+Colors.TEXT_RED+" can't define the radio by that name"
                        + Colors.TEXT_YELLOW+ ", path: '"+SymbolTable.formatPath(tempPath)+"'"+Colors.TEXT_RESET);
                SymbolTable.stop=true;
            }
        }else {
            ErrorHandling.error.add(Colors.TEXT_B+Colors.TEXT_RED+"[a name '"+Key+"' is found in the scope'"+scope+"']:"+Colors.TEXT_RESET+Colors.TEXT_RED+" can't define the radio by that name"
                    + Colors.TEXT_YELLOW+ ", path: '"+SymbolTable.formatPath(tempPath)+"'"+Colors.TEXT_RESET);
            SymbolTable.stop=true;
        }


    }
}
