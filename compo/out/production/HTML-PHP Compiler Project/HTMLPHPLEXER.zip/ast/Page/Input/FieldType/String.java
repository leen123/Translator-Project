package ast.Page.Input.FieldType;

public class String  {
    private java.lang.String text;

    public java.lang.String getText() {
        return text;
    }

    public void setText(java.lang.String text) {
        this.text = text;
    }
}
