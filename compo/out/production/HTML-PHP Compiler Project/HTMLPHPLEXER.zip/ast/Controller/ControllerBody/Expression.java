package ast.Controller.ControllerBody;

import ast.Controller.Variable;

public class Expression {
    private String operator;
    private LeftSideExpression leftSideExpression;
    private RightSideExpression rightSideExpression;
    private String connectOperator;
    private Expression connectedExpression;

    public String getConnectOperator() {
        return connectOperator;
    }

    public void setConnectOperator(String connectOperator) {
        this.connectOperator = connectOperator;
    }

    public Expression getConnectedExpression() {
        return connectedExpression;
    }

    public void setConnectedExpression(Expression connectedExpression) {
        this.connectedExpression = connectedExpression;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public LeftSideExpression getLeftSideExpression() {
        return leftSideExpression;
    }

    public void setLeftSideExpression(LeftSideExpression leftSideExpression) {
        this.leftSideExpression = leftSideExpression;
    }

    public RightSideExpression getRightSideExpression() {
        return rightSideExpression;
    }

    public void setRightSideExpression(RightSideExpression rightSideExpression) {
        this.rightSideExpression = rightSideExpression;
    }
}
