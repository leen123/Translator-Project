package ast.Controller.ControllerBody;

import ast.Controller.Variable;

public class RightSideExpression {
    String expressionString;
    Integer expressionInteger;
    Variable expressionVar;

    public String getExpressionString() {
        return expressionString;
    }

    public void setExpressionString(String expressionString) {
        this.expressionString = expressionString;
    }

    public Integer getExpressionInteger() {
        return expressionInteger;
    }

    public void setExpressionInteger(Integer expressionInteger) {
        this.expressionInteger = expressionInteger;
    }

    public Variable getExpressionVar() {
        return expressionVar;
    }

    public void setExpressionVar(Variable expressionVar) {
        this.expressionVar = expressionVar;
    }
}
