package ast.Controller.ControllerBody;

import color.Colors;
import error_handling.ErrorHandling;
import symbol_table.Row;
import symbol_table.SymbolTable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Goto {
    private String targetPage;

    public String getTargetPage() {
        return targetPage;
    }

    public void setTargetPage(String targetPage) {
        this.targetPage = targetPage;
    }
    public void debug(List key, String scope){
        Row row= SymbolTable.findRow(key);
        List tempPath=new ArrayList();
        tempPath.addAll(key);
        //  tempPath.add(arrayName);

            tempPath.add(targetPage);
            if(SymbolTable.checkFound(targetPage,"pageId","global").size()>0){
                row.table.put(targetPage,
                        new Row("gotoPageId",scope, tempPath));
            }else {
                ErrorHandling.error.add(Colors.TEXT_B+Colors.TEXT_RED+"[a name '"+targetPage+"' is not found]:"+Colors.TEXT_RESET+Colors.TEXT_RED+" can't define the Page by that name"+
                        Colors.TEXT_YELLOW+", path: '"+SymbolTable.formatPath(tempPath)+"'"+Colors.TEXT_RESET);
                SymbolTable.stop=true;
            }

    }
}
