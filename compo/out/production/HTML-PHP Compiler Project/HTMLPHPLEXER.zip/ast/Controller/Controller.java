package ast.Controller;

import ast.Controller.ControllerBody.ControllerBody;
import symbol_table.SymbolTable;

import java.util.LinkedList;
import java.util.List;

public class Controller {

    List<ControllerBody> bodies;
    public Controller (){
        this.bodies = new LinkedList<>();
    }
    public void addBody(ControllerBody controllerBody){
        this.bodies.add(controllerBody);
    }
    public List<ControllerBody> getBodies(){
        return this.bodies;
    }
    public void debug(List key){
        for (ControllerBody body:bodies) {
            body.debug(key,"controller");
            if(SymbolTable.stop) return;
        }
    }
}
