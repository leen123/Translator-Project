// Generated from D:/Mriwed/HTML-PHP Compiler Project (4)/src\HTMLPHPPARSER.g4 by ANTLR 4.9.2
package gen;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class HTMLPHPPARSER extends Parser {
	static { RuntimeMetaData.checkVersion("4.9.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		APP_WS=1, CONTROLLER_ATTR=2, PAGE_ATTR=3, PAGE_WS=4, EXTENDES=5, PAGE_ID=6, 
		OPEN_CURLY_BRACKETS=7, CONTROLLER_WS=8, CONTROLES_ATTR=9, ID=10, CONTROLLER_OPEN_BRACKETS=11, 
		CONTROLLER_SIMICOLON=12, CONTROLLER_BODY_WS=13, CLOSE_BRACKETS=14, IF=15, 
		ELSE_IF=16, ELSE=17, FOR=18, DEF=19, ADD_FUNC=20, TO_LOWER_FUNC=21, TO_UPPER_FUNC=22, 
		GOTO=23, TO_LOWER_FUNCTION_OPEN_BRACKETS=24, TO_LOWER_FUNCTION_VAR=25, 
		TO_LOWER_ARRAY_OPEN_BRACKETS=26, TO_LOWER_FUNCTION_CLOSE_BRACKETS=27, 
		TO_UPPER_FUNCTION_OPEN_BRACKETS=28, TO_UPPER_FUNCTION_VAR=29, TO_UPPER_ARRAY_OPEN_BRACKETS=30, 
		TO_UPPER_FUNCTION_CLOSE_BRACKETS=31, ADD_VAR=32, ADD_VAR_ARRAY_OPEN_BRACKETS=33, 
		ADD_VALUE=34, ADD_FUNCTION_COMMA=35, ADD_CLOSE_BRACKETS=36, ARRAY_DEF_WS=37, 
		ARRAY=38, ARRAY_WS=39, ARRAY_NAME=40, ARRAY_VALUES_COMMA=41, DEFIEND_ARRAY_OPEN_BRACKETS=42, 
		DEFIEND_ARRAY_CLOSE_BRACKETS=43, ARRAY_VAR_VALUES=44, ARRAY_INT_VALUES=45, 
		ARRAY_STRING_VALUES=46, GOTO_PAGE_ID=47, GOTO_WS=48, IF_WS=49, IF_OPEN_ARCH=50, 
		IF_OPEN_BRACKETS=51, FOR_MODE_OPEN_ARCH=52, FOR_MODE_CLOSE_ARCH=53, FOR_MODE_OPEN_BRACKETS=54, 
		EXPRESSION_WS=55, AND_AND_OPERATOR=56, OR_OPERATOR=57, BIGGER_OPERATOR=58, 
		SMALLER_OPERATOR=59, BIGGER_AND_EQUALS_OPERATOR=60, SMALLER_AND_EQUALS_OPERATOR=61, 
		EQUALS_OPERATOR=62, EXPRESSION_VAR=63, EXPRESSION_NUMBER=64, EXPRESSION_STRING=65, 
		EXPRESSION_ARRAY_OPEN_BRACKETS=66, IF_CLOSE_ARCH=67, ARRAY_INDEX_NUMER=68, 
		ARRAY_INDEX_VAR=69, EXPRESSION_ARRAY_CLOSE_BRACKETS=70, FOR_WS=71, RANGE=72, 
		IN=73, FOR_EXPRESSION_VAR=74, FOR_EXPRESSION_NUMBER=75, FOR_EXPRESSION_ARRAY_VAR_OPEN_BREACKETS=76, 
		FOR_RANGE_CLOSE_ARCH=77, FOR_RANGE_OPEN_ARCH=78, COMMA_EXPRESSION_COMMA=79, 
		IO_WS=80, IN_ATTR=81, OUT_ATT=82, LOCATION=83, SUBMIT=84, CLOSED_CURLY_BRACKETS=85, 
		INTPUT_WS=86, INPUT_COLON=87, INPUT_SIMICOLON=88, FIELD=89, CHECKBOX=90, 
		DROPDOWN=91, RADIO=92, FILE=93, INPUT_PARAM_OPEN_PARA=94, INPUT_PARAM_CLOSE_PARA=95, 
		OUTPUT_WS=96, OUTPUT_COLON=97, OUT_TEXT=98, OUT_IMAGE=99, OUTPUT_SIMICOLON=100, 
		INPUT_FIELD_OPEN_ARCH=101, INPUT_FIELD=102, INPUT_FIELD_CLOSE_ARCH=103, 
		INPUT_WS=104, CHOICE_NAME=105, INPUT_CHOCIE_OPEN_ARCH=106, INPUT_CHOICE_CLOSE__ARCH=107, 
		INPUT_CHOICE_COMMA=108, INPUT_DOUBLE_QUOTATION=109, INPUT_SINGLE_QUOTATION=110, 
		INPUT_NUMBER=111, DOUBLE_QUOT_INPUT_STRING=112, CLOSED_DOUBLE_QUOTATION=113, 
		SINGLE_QUOT_INPUT_STRING=114, CLOSED_SINGLE_QUOTATION=115, OUTPUT_PARAMS_WS=116, 
		OUTPUT_PARAM_OPEN_PARA=117, OUTPUT_TEXT=118, OUTPUT_PARAM_CLOSE_PARA=119, 
		IMAGE_PATH_DOUBLE_QUOTATIONS=120, OUTPUT_IMAGE_OPEN_PARA=121, OUTPUT_IMAGE_CLOSE_PARA=122, 
		LOCATION_OPEN_ARCH=123, CENTER=124, LEFT_UPPER=125, RIGHT_UPPER=126, LEFT_DOWN=127, 
		RIGHT_DOWN=128, LOCATION_CLOSE_ARCH=129;
	public static final int
		RULE_app = 0, RULE_define_page = 1, RULE_define_controller = 2, RULE_submit = 3, 
		RULE_body = 4, RULE_controller = 5, RULE_location = 6, RULE_controller_body = 7, 
		RULE_if_statement = 8, RULE_else_if = 9, RULE_else_end = 10, RULE_define_array = 11, 
		RULE_array_values = 12, RULE_for_loop = 13, RULE_var_or_number = 14, RULE_function = 15, 
		RULE_add_function = 16, RULE_to_lower_function = 17, RULE_to_upper_function = 18, 
		RULE_goto_page = 19, RULE_exepression = 20, RULE_left_expression = 21, 
		RULE_right_expression = 22, RULE_exepression_var = 23, RULE_exepression_operator = 24, 
		RULE_opertator = 25, RULE_array_bounds = 26, RULE_input = 27, RULE_output = 28, 
		RULE_field = 29, RULE_file = 30, RULE_image = 31, RULE_multiple_choice_field = 32, 
		RULE_image_path = 33, RULE_input_text = 34, RULE_string = 35, RULE_double_quotations_string = 36, 
		RULE_single_quotations_string = 37, RULE_integer = 38, RULE_checkbox = 39, 
		RULE_dropdown = 40, RULE_radio = 41, RULE_outputText = 42;
	private static String[] makeRuleNames() {
		return new String[] {
			"app", "define_page", "define_controller", "submit", "body", "controller", 
			"location", "controller_body", "if_statement", "else_if", "else_end", 
			"define_array", "array_values", "for_loop", "var_or_number", "function", 
			"add_function", "to_lower_function", "to_upper_function", "goto_page", 
			"exepression", "left_expression", "right_expression", "exepression_var", 
			"exepression_operator", "opertator", "array_bounds", "input", "output", 
			"field", "file", "image", "multiple_choice_field", "image_path", "input_text", 
			"string", "double_quotations_string", "single_quotations_string", "integer", 
			"checkbox", "dropdown", "radio", "outputText"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, "'controller'", "'page'", null, "'extends'", null, null, 
			null, "'controls'", null, null, null, null, null, "'if'", "'else if'", 
			"'else'", "'for'", "'def'", "'add('", "'toLower('", "'toUpper('", "'goto'", 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, "'array'", null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, "'&&'", "'||'", 
			"'>'", "'<'", "'>='", "'<='", "'=='", null, null, null, null, null, null, 
			null, "']'", null, "'range'", null, null, null, null, null, null, null, 
			null, null, "'out'", "'location'", "'submit'", null, null, null, null, 
			"'field'", "'checkbox'", "'dropdown'", "'radio'", "'file'", null, null, 
			null, null, "'text'", "'image'", null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, "'center'", "'left_upper'", "'right_upper'", 
			"'left_down'", "'right_down'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "APP_WS", "CONTROLLER_ATTR", "PAGE_ATTR", "PAGE_WS", "EXTENDES", 
			"PAGE_ID", "OPEN_CURLY_BRACKETS", "CONTROLLER_WS", "CONTROLES_ATTR", 
			"ID", "CONTROLLER_OPEN_BRACKETS", "CONTROLLER_SIMICOLON", "CONTROLLER_BODY_WS", 
			"CLOSE_BRACKETS", "IF", "ELSE_IF", "ELSE", "FOR", "DEF", "ADD_FUNC", 
			"TO_LOWER_FUNC", "TO_UPPER_FUNC", "GOTO", "TO_LOWER_FUNCTION_OPEN_BRACKETS", 
			"TO_LOWER_FUNCTION_VAR", "TO_LOWER_ARRAY_OPEN_BRACKETS", "TO_LOWER_FUNCTION_CLOSE_BRACKETS", 
			"TO_UPPER_FUNCTION_OPEN_BRACKETS", "TO_UPPER_FUNCTION_VAR", "TO_UPPER_ARRAY_OPEN_BRACKETS", 
			"TO_UPPER_FUNCTION_CLOSE_BRACKETS", "ADD_VAR", "ADD_VAR_ARRAY_OPEN_BRACKETS", 
			"ADD_VALUE", "ADD_FUNCTION_COMMA", "ADD_CLOSE_BRACKETS", "ARRAY_DEF_WS", 
			"ARRAY", "ARRAY_WS", "ARRAY_NAME", "ARRAY_VALUES_COMMA", "DEFIEND_ARRAY_OPEN_BRACKETS", 
			"DEFIEND_ARRAY_CLOSE_BRACKETS", "ARRAY_VAR_VALUES", "ARRAY_INT_VALUES", 
			"ARRAY_STRING_VALUES", "GOTO_PAGE_ID", "GOTO_WS", "IF_WS", "IF_OPEN_ARCH", 
			"IF_OPEN_BRACKETS", "FOR_MODE_OPEN_ARCH", "FOR_MODE_CLOSE_ARCH", "FOR_MODE_OPEN_BRACKETS", 
			"EXPRESSION_WS", "AND_AND_OPERATOR", "OR_OPERATOR", "BIGGER_OPERATOR", 
			"SMALLER_OPERATOR", "BIGGER_AND_EQUALS_OPERATOR", "SMALLER_AND_EQUALS_OPERATOR", 
			"EQUALS_OPERATOR", "EXPRESSION_VAR", "EXPRESSION_NUMBER", "EXPRESSION_STRING", 
			"EXPRESSION_ARRAY_OPEN_BRACKETS", "IF_CLOSE_ARCH", "ARRAY_INDEX_NUMER", 
			"ARRAY_INDEX_VAR", "EXPRESSION_ARRAY_CLOSE_BRACKETS", "FOR_WS", "RANGE", 
			"IN", "FOR_EXPRESSION_VAR", "FOR_EXPRESSION_NUMBER", "FOR_EXPRESSION_ARRAY_VAR_OPEN_BREACKETS", 
			"FOR_RANGE_CLOSE_ARCH", "FOR_RANGE_OPEN_ARCH", "COMMA_EXPRESSION_COMMA", 
			"IO_WS", "IN_ATTR", "OUT_ATT", "LOCATION", "SUBMIT", "CLOSED_CURLY_BRACKETS", 
			"INTPUT_WS", "INPUT_COLON", "INPUT_SIMICOLON", "FIELD", "CHECKBOX", "DROPDOWN", 
			"RADIO", "FILE", "INPUT_PARAM_OPEN_PARA", "INPUT_PARAM_CLOSE_PARA", "OUTPUT_WS", 
			"OUTPUT_COLON", "OUT_TEXT", "OUT_IMAGE", "OUTPUT_SIMICOLON", "INPUT_FIELD_OPEN_ARCH", 
			"INPUT_FIELD", "INPUT_FIELD_CLOSE_ARCH", "INPUT_WS", "CHOICE_NAME", "INPUT_CHOCIE_OPEN_ARCH", 
			"INPUT_CHOICE_CLOSE__ARCH", "INPUT_CHOICE_COMMA", "INPUT_DOUBLE_QUOTATION", 
			"INPUT_SINGLE_QUOTATION", "INPUT_NUMBER", "DOUBLE_QUOT_INPUT_STRING", 
			"CLOSED_DOUBLE_QUOTATION", "SINGLE_QUOT_INPUT_STRING", "CLOSED_SINGLE_QUOTATION", 
			"OUTPUT_PARAMS_WS", "OUTPUT_PARAM_OPEN_PARA", "OUTPUT_TEXT", "OUTPUT_PARAM_CLOSE_PARA", 
			"IMAGE_PATH_DOUBLE_QUOTATIONS", "OUTPUT_IMAGE_OPEN_PARA", "OUTPUT_IMAGE_CLOSE_PARA", 
			"LOCATION_OPEN_ARCH", "CENTER", "LEFT_UPPER", "RIGHT_UPPER", "LEFT_DOWN", 
			"RIGHT_DOWN", "LOCATION_CLOSE_ARCH"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "HTMLPHPPARSER.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public HTMLPHPPARSER(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class AppContext extends ParserRuleContext {
		public List<Define_pageContext> define_page() {
			return getRuleContexts(Define_pageContext.class);
		}
		public Define_pageContext define_page(int i) {
			return getRuleContext(Define_pageContext.class,i);
		}
		public List<Define_controllerContext> define_controller() {
			return getRuleContexts(Define_controllerContext.class);
		}
		public Define_controllerContext define_controller(int i) {
			return getRuleContext(Define_controllerContext.class,i);
		}
		public AppContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_app; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterApp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitApp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitApp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AppContext app() throws RecognitionException {
		AppContext _localctx = new AppContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_app);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(87); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(86);
				define_page();
				}
				}
				setState(89); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==PAGE_ATTR );
			setState(92); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(91);
				define_controller();
				}
				}
				setState(94); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==CONTROLLER_ATTR );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Define_pageContext extends ParserRuleContext {
		public TerminalNode PAGE_ATTR() { return getToken(HTMLPHPPARSER.PAGE_ATTR, 0); }
		public List<TerminalNode> PAGE_ID() { return getTokens(HTMLPHPPARSER.PAGE_ID); }
		public TerminalNode PAGE_ID(int i) {
			return getToken(HTMLPHPPARSER.PAGE_ID, i);
		}
		public TerminalNode OPEN_CURLY_BRACKETS() { return getToken(HTMLPHPPARSER.OPEN_CURLY_BRACKETS, 0); }
		public SubmitContext submit() {
			return getRuleContext(SubmitContext.class,0);
		}
		public TerminalNode CLOSED_CURLY_BRACKETS() { return getToken(HTMLPHPPARSER.CLOSED_CURLY_BRACKETS, 0); }
		public TerminalNode EXTENDES() { return getToken(HTMLPHPPARSER.EXTENDES, 0); }
		public List<BodyContext> body() {
			return getRuleContexts(BodyContext.class);
		}
		public BodyContext body(int i) {
			return getRuleContext(BodyContext.class,i);
		}
		public Define_pageContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_define_page; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterDefine_page(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitDefine_page(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitDefine_page(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Define_pageContext define_page() throws RecognitionException {
		Define_pageContext _localctx = new Define_pageContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_define_page);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(96);
			match(PAGE_ATTR);
			setState(97);
			match(PAGE_ID);
			setState(100);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==EXTENDES) {
				{
				setState(98);
				match(EXTENDES);
				setState(99);
				match(PAGE_ID);
				}
			}

			setState(102);
			match(OPEN_CURLY_BRACKETS);
			setState(106);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==IN_ATTR || _la==OUT_ATT) {
				{
				{
				setState(103);
				body();
				}
				}
				setState(108);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(109);
			submit();
			setState(110);
			match(CLOSED_CURLY_BRACKETS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Define_controllerContext extends ParserRuleContext {
		public TerminalNode CONTROLLER_ATTR() { return getToken(HTMLPHPPARSER.CONTROLLER_ATTR, 0); }
		public List<TerminalNode> ID() { return getTokens(HTMLPHPPARSER.ID); }
		public TerminalNode ID(int i) {
			return getToken(HTMLPHPPARSER.ID, i);
		}
		public TerminalNode CONTROLES_ATTR() { return getToken(HTMLPHPPARSER.CONTROLES_ATTR, 0); }
		public ControllerContext controller() {
			return getRuleContext(ControllerContext.class,0);
		}
		public Define_controllerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_define_controller; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterDefine_controller(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitDefine_controller(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitDefine_controller(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Define_controllerContext define_controller() throws RecognitionException {
		Define_controllerContext _localctx = new Define_controllerContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_define_controller);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(112);
			match(CONTROLLER_ATTR);
			setState(113);
			match(ID);
			setState(114);
			match(CONTROLES_ATTR);
			setState(115);
			match(ID);
			setState(116);
			controller();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SubmitContext extends ParserRuleContext {
		public TerminalNode SUBMIT() { return getToken(HTMLPHPPARSER.SUBMIT, 0); }
		public LocationContext location() {
			return getRuleContext(LocationContext.class,0);
		}
		public SubmitContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_submit; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterSubmit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitSubmit(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitSubmit(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubmitContext submit() throws RecognitionException {
		SubmitContext _localctx = new SubmitContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_submit);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(118);
			match(SUBMIT);
			setState(119);
			location();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BodyContext extends ParserRuleContext {
		public InputContext input() {
			return getRuleContext(InputContext.class,0);
		}
		public OutputContext output() {
			return getRuleContext(OutputContext.class,0);
		}
		public BodyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_body; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterBody(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitBody(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitBody(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BodyContext body() throws RecognitionException {
		BodyContext _localctx = new BodyContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_body);
		try {
			setState(123);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IN_ATTR:
				enterOuterAlt(_localctx, 1);
				{
				setState(121);
				input();
				}
				break;
			case OUT_ATT:
				enterOuterAlt(_localctx, 2);
				{
				setState(122);
				output();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ControllerContext extends ParserRuleContext {
		public TerminalNode CONTROLLER_OPEN_BRACKETS() { return getToken(HTMLPHPPARSER.CONTROLLER_OPEN_BRACKETS, 0); }
		public TerminalNode CLOSE_BRACKETS() { return getToken(HTMLPHPPARSER.CLOSE_BRACKETS, 0); }
		public TerminalNode CONTROLLER_SIMICOLON() { return getToken(HTMLPHPPARSER.CONTROLLER_SIMICOLON, 0); }
		public List<Controller_bodyContext> controller_body() {
			return getRuleContexts(Controller_bodyContext.class);
		}
		public Controller_bodyContext controller_body(int i) {
			return getRuleContext(Controller_bodyContext.class,i);
		}
		public ControllerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_controller; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterController(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitController(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitController(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ControllerContext controller() throws RecognitionException {
		ControllerContext _localctx = new ControllerContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_controller);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(125);
			match(CONTROLLER_OPEN_BRACKETS);
			setState(129);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << IF) | (1L << FOR) | (1L << DEF) | (1L << ADD_FUNC) | (1L << TO_LOWER_FUNC) | (1L << TO_UPPER_FUNC) | (1L << GOTO))) != 0)) {
				{
				{
				setState(126);
				controller_body();
				}
				}
				setState(131);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(132);
			match(CLOSE_BRACKETS);
			setState(133);
			match(CONTROLLER_SIMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LocationContext extends ParserRuleContext {
		public TerminalNode LOCATION() { return getToken(HTMLPHPPARSER.LOCATION, 0); }
		public TerminalNode LOCATION_OPEN_ARCH() { return getToken(HTMLPHPPARSER.LOCATION_OPEN_ARCH, 0); }
		public TerminalNode LOCATION_CLOSE_ARCH() { return getToken(HTMLPHPPARSER.LOCATION_CLOSE_ARCH, 0); }
		public TerminalNode CENTER() { return getToken(HTMLPHPPARSER.CENTER, 0); }
		public TerminalNode LEFT_UPPER() { return getToken(HTMLPHPPARSER.LEFT_UPPER, 0); }
		public TerminalNode RIGHT_UPPER() { return getToken(HTMLPHPPARSER.RIGHT_UPPER, 0); }
		public TerminalNode LEFT_DOWN() { return getToken(HTMLPHPPARSER.LEFT_DOWN, 0); }
		public TerminalNode RIGHT_DOWN() { return getToken(HTMLPHPPARSER.RIGHT_DOWN, 0); }
		public LocationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_location; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterLocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitLocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitLocation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocationContext location() throws RecognitionException {
		LocationContext _localctx = new LocationContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_location);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(135);
			match(LOCATION);
			setState(136);
			match(LOCATION_OPEN_ARCH);
			setState(137);
			_la = _input.LA(1);
			if ( !(((((_la - 124)) & ~0x3f) == 0 && ((1L << (_la - 124)) & ((1L << (CENTER - 124)) | (1L << (LEFT_UPPER - 124)) | (1L << (RIGHT_UPPER - 124)) | (1L << (LEFT_DOWN - 124)) | (1L << (RIGHT_DOWN - 124)))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(138);
			match(LOCATION_CLOSE_ARCH);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Controller_bodyContext extends ParserRuleContext {
		public Define_arrayContext define_array() {
			return getRuleContext(Define_arrayContext.class,0);
		}
		public If_statementContext if_statement() {
			return getRuleContext(If_statementContext.class,0);
		}
		public For_loopContext for_loop() {
			return getRuleContext(For_loopContext.class,0);
		}
		public FunctionContext function() {
			return getRuleContext(FunctionContext.class,0);
		}
		public Goto_pageContext goto_page() {
			return getRuleContext(Goto_pageContext.class,0);
		}
		public Controller_bodyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_controller_body; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterController_body(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitController_body(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitController_body(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Controller_bodyContext controller_body() throws RecognitionException {
		Controller_bodyContext _localctx = new Controller_bodyContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_controller_body);
		try {
			setState(145);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case DEF:
				enterOuterAlt(_localctx, 1);
				{
				setState(140);
				define_array();
				}
				break;
			case IF:
				enterOuterAlt(_localctx, 2);
				{
				setState(141);
				if_statement();
				}
				break;
			case FOR:
				enterOuterAlt(_localctx, 3);
				{
				setState(142);
				for_loop();
				}
				break;
			case ADD_FUNC:
			case TO_LOWER_FUNC:
			case TO_UPPER_FUNC:
				enterOuterAlt(_localctx, 4);
				{
				setState(143);
				function();
				}
				break;
			case GOTO:
				enterOuterAlt(_localctx, 5);
				{
				setState(144);
				goto_page();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class If_statementContext extends ParserRuleContext {
		public TerminalNode IF() { return getToken(HTMLPHPPARSER.IF, 0); }
		public TerminalNode IF_OPEN_ARCH() { return getToken(HTMLPHPPARSER.IF_OPEN_ARCH, 0); }
		public ExepressionContext exepression() {
			return getRuleContext(ExepressionContext.class,0);
		}
		public TerminalNode IF_CLOSE_ARCH() { return getToken(HTMLPHPPARSER.IF_CLOSE_ARCH, 0); }
		public TerminalNode IF_OPEN_BRACKETS() { return getToken(HTMLPHPPARSER.IF_OPEN_BRACKETS, 0); }
		public TerminalNode CLOSE_BRACKETS() { return getToken(HTMLPHPPARSER.CLOSE_BRACKETS, 0); }
		public List<Controller_bodyContext> controller_body() {
			return getRuleContexts(Controller_bodyContext.class);
		}
		public Controller_bodyContext controller_body(int i) {
			return getRuleContext(Controller_bodyContext.class,i);
		}
		public List<Else_ifContext> else_if() {
			return getRuleContexts(Else_ifContext.class);
		}
		public Else_ifContext else_if(int i) {
			return getRuleContext(Else_ifContext.class,i);
		}
		public Else_endContext else_end() {
			return getRuleContext(Else_endContext.class,0);
		}
		public If_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_if_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterIf_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitIf_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitIf_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final If_statementContext if_statement() throws RecognitionException {
		If_statementContext _localctx = new If_statementContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_if_statement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(147);
			match(IF);
			setState(148);
			match(IF_OPEN_ARCH);
			setState(149);
			exepression();
			setState(150);
			match(IF_CLOSE_ARCH);
			setState(151);
			match(IF_OPEN_BRACKETS);
			setState(155);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << IF) | (1L << FOR) | (1L << DEF) | (1L << ADD_FUNC) | (1L << TO_LOWER_FUNC) | (1L << TO_UPPER_FUNC) | (1L << GOTO))) != 0)) {
				{
				{
				setState(152);
				controller_body();
				}
				}
				setState(157);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(158);
			match(CLOSE_BRACKETS);
			setState(162);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ELSE_IF) {
				{
				{
				setState(159);
				else_if();
				}
				}
				setState(164);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(166);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ELSE) {
				{
				setState(165);
				else_end();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Else_ifContext extends ParserRuleContext {
		public TerminalNode ELSE_IF() { return getToken(HTMLPHPPARSER.ELSE_IF, 0); }
		public TerminalNode IF_OPEN_ARCH() { return getToken(HTMLPHPPARSER.IF_OPEN_ARCH, 0); }
		public ExepressionContext exepression() {
			return getRuleContext(ExepressionContext.class,0);
		}
		public TerminalNode IF_CLOSE_ARCH() { return getToken(HTMLPHPPARSER.IF_CLOSE_ARCH, 0); }
		public TerminalNode IF_OPEN_BRACKETS() { return getToken(HTMLPHPPARSER.IF_OPEN_BRACKETS, 0); }
		public TerminalNode CLOSE_BRACKETS() { return getToken(HTMLPHPPARSER.CLOSE_BRACKETS, 0); }
		public List<Controller_bodyContext> controller_body() {
			return getRuleContexts(Controller_bodyContext.class);
		}
		public Controller_bodyContext controller_body(int i) {
			return getRuleContext(Controller_bodyContext.class,i);
		}
		public Else_ifContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_else_if; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterElse_if(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitElse_if(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitElse_if(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Else_ifContext else_if() throws RecognitionException {
		Else_ifContext _localctx = new Else_ifContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_else_if);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(168);
			match(ELSE_IF);
			setState(169);
			match(IF_OPEN_ARCH);
			setState(170);
			exepression();
			setState(171);
			match(IF_CLOSE_ARCH);
			setState(172);
			match(IF_OPEN_BRACKETS);
			setState(176);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << IF) | (1L << FOR) | (1L << DEF) | (1L << ADD_FUNC) | (1L << TO_LOWER_FUNC) | (1L << TO_UPPER_FUNC) | (1L << GOTO))) != 0)) {
				{
				{
				setState(173);
				controller_body();
				}
				}
				setState(178);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(179);
			match(CLOSE_BRACKETS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Else_endContext extends ParserRuleContext {
		public TerminalNode ELSE() { return getToken(HTMLPHPPARSER.ELSE, 0); }
		public TerminalNode IF_OPEN_BRACKETS() { return getToken(HTMLPHPPARSER.IF_OPEN_BRACKETS, 0); }
		public TerminalNode CLOSE_BRACKETS() { return getToken(HTMLPHPPARSER.CLOSE_BRACKETS, 0); }
		public List<Controller_bodyContext> controller_body() {
			return getRuleContexts(Controller_bodyContext.class);
		}
		public Controller_bodyContext controller_body(int i) {
			return getRuleContext(Controller_bodyContext.class,i);
		}
		public Else_endContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_else_end; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterElse_end(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitElse_end(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitElse_end(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Else_endContext else_end() throws RecognitionException {
		Else_endContext _localctx = new Else_endContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_else_end);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(181);
			match(ELSE);
			setState(182);
			match(IF_OPEN_BRACKETS);
			setState(186);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << IF) | (1L << FOR) | (1L << DEF) | (1L << ADD_FUNC) | (1L << TO_LOWER_FUNC) | (1L << TO_UPPER_FUNC) | (1L << GOTO))) != 0)) {
				{
				{
				setState(183);
				controller_body();
				}
				}
				setState(188);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(189);
			match(CLOSE_BRACKETS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Define_arrayContext extends ParserRuleContext {
		public TerminalNode DEF() { return getToken(HTMLPHPPARSER.DEF, 0); }
		public TerminalNode ARRAY() { return getToken(HTMLPHPPARSER.ARRAY, 0); }
		public TerminalNode ARRAY_NAME() { return getToken(HTMLPHPPARSER.ARRAY_NAME, 0); }
		public TerminalNode DEFIEND_ARRAY_OPEN_BRACKETS() { return getToken(HTMLPHPPARSER.DEFIEND_ARRAY_OPEN_BRACKETS, 0); }
		public TerminalNode DEFIEND_ARRAY_CLOSE_BRACKETS() { return getToken(HTMLPHPPARSER.DEFIEND_ARRAY_CLOSE_BRACKETS, 0); }
		public List<Array_valuesContext> array_values() {
			return getRuleContexts(Array_valuesContext.class);
		}
		public Array_valuesContext array_values(int i) {
			return getRuleContext(Array_valuesContext.class,i);
		}
		public List<TerminalNode> ARRAY_VALUES_COMMA() { return getTokens(HTMLPHPPARSER.ARRAY_VALUES_COMMA); }
		public TerminalNode ARRAY_VALUES_COMMA(int i) {
			return getToken(HTMLPHPPARSER.ARRAY_VALUES_COMMA, i);
		}
		public Define_arrayContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_define_array; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterDefine_array(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitDefine_array(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitDefine_array(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Define_arrayContext define_array() throws RecognitionException {
		Define_arrayContext _localctx = new Define_arrayContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_define_array);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(191);
			match(DEF);
			setState(192);
			match(ARRAY);
			setState(193);
			match(ARRAY_NAME);
			setState(194);
			match(DEFIEND_ARRAY_OPEN_BRACKETS);
			setState(199); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(195);
				array_values();
				setState(197);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ARRAY_VALUES_COMMA) {
					{
					setState(196);
					match(ARRAY_VALUES_COMMA);
					}
				}

				}
				}
				setState(201); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << ARRAY_VAR_VALUES) | (1L << ARRAY_INT_VALUES) | (1L << ARRAY_STRING_VALUES))) != 0) );
			setState(203);
			match(DEFIEND_ARRAY_CLOSE_BRACKETS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Array_valuesContext extends ParserRuleContext {
		public TerminalNode ARRAY_VAR_VALUES() { return getToken(HTMLPHPPARSER.ARRAY_VAR_VALUES, 0); }
		public TerminalNode ARRAY_INT_VALUES() { return getToken(HTMLPHPPARSER.ARRAY_INT_VALUES, 0); }
		public TerminalNode ARRAY_STRING_VALUES() { return getToken(HTMLPHPPARSER.ARRAY_STRING_VALUES, 0); }
		public Array_valuesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_array_values; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterArray_values(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitArray_values(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitArray_values(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Array_valuesContext array_values() throws RecognitionException {
		Array_valuesContext _localctx = new Array_valuesContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_array_values);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(205);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << ARRAY_VAR_VALUES) | (1L << ARRAY_INT_VALUES) | (1L << ARRAY_STRING_VALUES))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class For_loopContext extends ParserRuleContext {
		public TerminalNode FOR() { return getToken(HTMLPHPPARSER.FOR, 0); }
		public TerminalNode FOR_MODE_OPEN_ARCH() { return getToken(HTMLPHPPARSER.FOR_MODE_OPEN_ARCH, 0); }
		public TerminalNode FOR_EXPRESSION_VAR() { return getToken(HTMLPHPPARSER.FOR_EXPRESSION_VAR, 0); }
		public TerminalNode IN() { return getToken(HTMLPHPPARSER.IN, 0); }
		public TerminalNode RANGE() { return getToken(HTMLPHPPARSER.RANGE, 0); }
		public TerminalNode FOR_RANGE_OPEN_ARCH() { return getToken(HTMLPHPPARSER.FOR_RANGE_OPEN_ARCH, 0); }
		public List<Var_or_numberContext> var_or_number() {
			return getRuleContexts(Var_or_numberContext.class);
		}
		public Var_or_numberContext var_or_number(int i) {
			return getRuleContext(Var_or_numberContext.class,i);
		}
		public TerminalNode COMMA_EXPRESSION_COMMA() { return getToken(HTMLPHPPARSER.COMMA_EXPRESSION_COMMA, 0); }
		public TerminalNode FOR_RANGE_CLOSE_ARCH() { return getToken(HTMLPHPPARSER.FOR_RANGE_CLOSE_ARCH, 0); }
		public TerminalNode FOR_MODE_CLOSE_ARCH() { return getToken(HTMLPHPPARSER.FOR_MODE_CLOSE_ARCH, 0); }
		public TerminalNode FOR_MODE_OPEN_BRACKETS() { return getToken(HTMLPHPPARSER.FOR_MODE_OPEN_BRACKETS, 0); }
		public TerminalNode CLOSE_BRACKETS() { return getToken(HTMLPHPPARSER.CLOSE_BRACKETS, 0); }
		public List<Controller_bodyContext> controller_body() {
			return getRuleContexts(Controller_bodyContext.class);
		}
		public Controller_bodyContext controller_body(int i) {
			return getRuleContext(Controller_bodyContext.class,i);
		}
		public For_loopContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_for_loop; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterFor_loop(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitFor_loop(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitFor_loop(this);
			else return visitor.visitChildren(this);
		}
	}

	public final For_loopContext for_loop() throws RecognitionException {
		For_loopContext _localctx = new For_loopContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_for_loop);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(207);
			match(FOR);
			setState(208);
			match(FOR_MODE_OPEN_ARCH);
			setState(209);
			match(FOR_EXPRESSION_VAR);
			setState(210);
			match(IN);
			setState(211);
			match(RANGE);
			setState(212);
			match(FOR_RANGE_OPEN_ARCH);
			setState(213);
			var_or_number();
			setState(214);
			match(COMMA_EXPRESSION_COMMA);
			setState(215);
			var_or_number();
			setState(216);
			match(FOR_RANGE_CLOSE_ARCH);
			setState(217);
			match(FOR_MODE_CLOSE_ARCH);
			setState(218);
			match(FOR_MODE_OPEN_BRACKETS);
			setState(222);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << IF) | (1L << FOR) | (1L << DEF) | (1L << ADD_FUNC) | (1L << TO_LOWER_FUNC) | (1L << TO_UPPER_FUNC) | (1L << GOTO))) != 0)) {
				{
				{
				setState(219);
				controller_body();
				}
				}
				setState(224);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(225);
			match(CLOSE_BRACKETS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Var_or_numberContext extends ParserRuleContext {
		public TerminalNode FOR_EXPRESSION_VAR() { return getToken(HTMLPHPPARSER.FOR_EXPRESSION_VAR, 0); }
		public List<Array_boundsContext> array_bounds() {
			return getRuleContexts(Array_boundsContext.class);
		}
		public Array_boundsContext array_bounds(int i) {
			return getRuleContext(Array_boundsContext.class,i);
		}
		public TerminalNode FOR_EXPRESSION_NUMBER() { return getToken(HTMLPHPPARSER.FOR_EXPRESSION_NUMBER, 0); }
		public Var_or_numberContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_var_or_number; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterVar_or_number(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitVar_or_number(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitVar_or_number(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Var_or_numberContext var_or_number() throws RecognitionException {
		Var_or_numberContext _localctx = new Var_or_numberContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_var_or_number);
		int _la;
		try {
			setState(235);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case FOR_EXPRESSION_VAR:
				enterOuterAlt(_localctx, 1);
				{
				{
				setState(227);
				match(FOR_EXPRESSION_VAR);
				setState(231);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (((((_la - 26)) & ~0x3f) == 0 && ((1L << (_la - 26)) & ((1L << (TO_LOWER_ARRAY_OPEN_BRACKETS - 26)) | (1L << (TO_UPPER_ARRAY_OPEN_BRACKETS - 26)) | (1L << (ADD_VAR_ARRAY_OPEN_BRACKETS - 26)) | (1L << (EXPRESSION_ARRAY_OPEN_BRACKETS - 26)) | (1L << (FOR_EXPRESSION_ARRAY_VAR_OPEN_BREACKETS - 26)))) != 0)) {
					{
					{
					setState(228);
					array_bounds();
					}
					}
					setState(233);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				break;
			case FOR_EXPRESSION_NUMBER:
				enterOuterAlt(_localctx, 2);
				{
				setState(234);
				match(FOR_EXPRESSION_NUMBER);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionContext extends ParserRuleContext {
		public Add_functionContext add_function() {
			return getRuleContext(Add_functionContext.class,0);
		}
		public To_lower_functionContext to_lower_function() {
			return getRuleContext(To_lower_functionContext.class,0);
		}
		public To_upper_functionContext to_upper_function() {
			return getRuleContext(To_upper_functionContext.class,0);
		}
		public FunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctionContext function() throws RecognitionException {
		FunctionContext _localctx = new FunctionContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_function);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(240);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ADD_FUNC:
				{
				setState(237);
				add_function();
				}
				break;
			case TO_LOWER_FUNC:
				{
				setState(238);
				to_lower_function();
				}
				break;
			case TO_UPPER_FUNC:
				{
				setState(239);
				to_upper_function();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Add_functionContext extends ParserRuleContext {
		public TerminalNode ADD_FUNC() { return getToken(HTMLPHPPARSER.ADD_FUNC, 0); }
		public TerminalNode ADD_VAR() { return getToken(HTMLPHPPARSER.ADD_VAR, 0); }
		public TerminalNode ADD_FUNCTION_COMMA() { return getToken(HTMLPHPPARSER.ADD_FUNCTION_COMMA, 0); }
		public TerminalNode ADD_VALUE() { return getToken(HTMLPHPPARSER.ADD_VALUE, 0); }
		public TerminalNode ADD_CLOSE_BRACKETS() { return getToken(HTMLPHPPARSER.ADD_CLOSE_BRACKETS, 0); }
		public List<Array_boundsContext> array_bounds() {
			return getRuleContexts(Array_boundsContext.class);
		}
		public Array_boundsContext array_bounds(int i) {
			return getRuleContext(Array_boundsContext.class,i);
		}
		public Add_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_add_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterAdd_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitAdd_function(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitAdd_function(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Add_functionContext add_function() throws RecognitionException {
		Add_functionContext _localctx = new Add_functionContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_add_function);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(242);
			match(ADD_FUNC);
			setState(243);
			match(ADD_VAR);
			setState(247);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 26)) & ~0x3f) == 0 && ((1L << (_la - 26)) & ((1L << (TO_LOWER_ARRAY_OPEN_BRACKETS - 26)) | (1L << (TO_UPPER_ARRAY_OPEN_BRACKETS - 26)) | (1L << (ADD_VAR_ARRAY_OPEN_BRACKETS - 26)) | (1L << (EXPRESSION_ARRAY_OPEN_BRACKETS - 26)) | (1L << (FOR_EXPRESSION_ARRAY_VAR_OPEN_BREACKETS - 26)))) != 0)) {
				{
				{
				setState(244);
				array_bounds();
				}
				}
				setState(249);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(250);
			match(ADD_FUNCTION_COMMA);
			setState(251);
			match(ADD_VALUE);
			setState(252);
			match(ADD_CLOSE_BRACKETS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class To_lower_functionContext extends ParserRuleContext {
		public TerminalNode TO_LOWER_FUNC() { return getToken(HTMLPHPPARSER.TO_LOWER_FUNC, 0); }
		public TerminalNode TO_LOWER_FUNCTION_VAR() { return getToken(HTMLPHPPARSER.TO_LOWER_FUNCTION_VAR, 0); }
		public TerminalNode TO_LOWER_FUNCTION_CLOSE_BRACKETS() { return getToken(HTMLPHPPARSER.TO_LOWER_FUNCTION_CLOSE_BRACKETS, 0); }
		public List<Array_boundsContext> array_bounds() {
			return getRuleContexts(Array_boundsContext.class);
		}
		public Array_boundsContext array_bounds(int i) {
			return getRuleContext(Array_boundsContext.class,i);
		}
		public To_lower_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_to_lower_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterTo_lower_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitTo_lower_function(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitTo_lower_function(this);
			else return visitor.visitChildren(this);
		}
	}

	public final To_lower_functionContext to_lower_function() throws RecognitionException {
		To_lower_functionContext _localctx = new To_lower_functionContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_to_lower_function);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(254);
			match(TO_LOWER_FUNC);
			setState(255);
			match(TO_LOWER_FUNCTION_VAR);
			setState(259);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 26)) & ~0x3f) == 0 && ((1L << (_la - 26)) & ((1L << (TO_LOWER_ARRAY_OPEN_BRACKETS - 26)) | (1L << (TO_UPPER_ARRAY_OPEN_BRACKETS - 26)) | (1L << (ADD_VAR_ARRAY_OPEN_BRACKETS - 26)) | (1L << (EXPRESSION_ARRAY_OPEN_BRACKETS - 26)) | (1L << (FOR_EXPRESSION_ARRAY_VAR_OPEN_BREACKETS - 26)))) != 0)) {
				{
				{
				setState(256);
				array_bounds();
				}
				}
				setState(261);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(262);
			match(TO_LOWER_FUNCTION_CLOSE_BRACKETS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class To_upper_functionContext extends ParserRuleContext {
		public TerminalNode TO_UPPER_FUNC() { return getToken(HTMLPHPPARSER.TO_UPPER_FUNC, 0); }
		public TerminalNode TO_UPPER_FUNCTION_VAR() { return getToken(HTMLPHPPARSER.TO_UPPER_FUNCTION_VAR, 0); }
		public TerminalNode TO_UPPER_FUNCTION_CLOSE_BRACKETS() { return getToken(HTMLPHPPARSER.TO_UPPER_FUNCTION_CLOSE_BRACKETS, 0); }
		public List<Array_boundsContext> array_bounds() {
			return getRuleContexts(Array_boundsContext.class);
		}
		public Array_boundsContext array_bounds(int i) {
			return getRuleContext(Array_boundsContext.class,i);
		}
		public To_upper_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_to_upper_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterTo_upper_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitTo_upper_function(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitTo_upper_function(this);
			else return visitor.visitChildren(this);
		}
	}

	public final To_upper_functionContext to_upper_function() throws RecognitionException {
		To_upper_functionContext _localctx = new To_upper_functionContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_to_upper_function);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(264);
			match(TO_UPPER_FUNC);
			setState(265);
			match(TO_UPPER_FUNCTION_VAR);
			setState(269);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 26)) & ~0x3f) == 0 && ((1L << (_la - 26)) & ((1L << (TO_LOWER_ARRAY_OPEN_BRACKETS - 26)) | (1L << (TO_UPPER_ARRAY_OPEN_BRACKETS - 26)) | (1L << (ADD_VAR_ARRAY_OPEN_BRACKETS - 26)) | (1L << (EXPRESSION_ARRAY_OPEN_BRACKETS - 26)) | (1L << (FOR_EXPRESSION_ARRAY_VAR_OPEN_BREACKETS - 26)))) != 0)) {
				{
				{
				setState(266);
				array_bounds();
				}
				}
				setState(271);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(272);
			match(TO_UPPER_FUNCTION_CLOSE_BRACKETS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Goto_pageContext extends ParserRuleContext {
		public TerminalNode GOTO() { return getToken(HTMLPHPPARSER.GOTO, 0); }
		public TerminalNode GOTO_PAGE_ID() { return getToken(HTMLPHPPARSER.GOTO_PAGE_ID, 0); }
		public Goto_pageContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_goto_page; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterGoto_page(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitGoto_page(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitGoto_page(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Goto_pageContext goto_page() throws RecognitionException {
		Goto_pageContext _localctx = new Goto_pageContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_goto_page);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(274);
			match(GOTO);
			setState(275);
			match(GOTO_PAGE_ID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExepressionContext extends ParserRuleContext {
		public Left_expressionContext left_expression() {
			return getRuleContext(Left_expressionContext.class,0);
		}
		public OpertatorContext opertator() {
			return getRuleContext(OpertatorContext.class,0);
		}
		public Right_expressionContext right_expression() {
			return getRuleContext(Right_expressionContext.class,0);
		}
		public Exepression_operatorContext exepression_operator() {
			return getRuleContext(Exepression_operatorContext.class,0);
		}
		public ExepressionContext exepression() {
			return getRuleContext(ExepressionContext.class,0);
		}
		public ExepressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exepression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterExepression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitExepression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitExepression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExepressionContext exepression() throws RecognitionException {
		ExepressionContext _localctx = new ExepressionContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_exepression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(277);
			left_expression();
			setState(278);
			opertator();
			setState(279);
			right_expression();
			setState(283);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AND_AND_OPERATOR || _la==OR_OPERATOR) {
				{
				setState(280);
				exepression_operator();
				setState(281);
				exepression();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Left_expressionContext extends ParserRuleContext {
		public TerminalNode EXPRESSION_NUMBER() { return getToken(HTMLPHPPARSER.EXPRESSION_NUMBER, 0); }
		public TerminalNode EXPRESSION_STRING() { return getToken(HTMLPHPPARSER.EXPRESSION_STRING, 0); }
		public Exepression_varContext exepression_var() {
			return getRuleContext(Exepression_varContext.class,0);
		}
		public Left_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_left_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterLeft_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitLeft_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitLeft_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Left_expressionContext left_expression() throws RecognitionException {
		Left_expressionContext _localctx = new Left_expressionContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_left_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(288);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case EXPRESSION_NUMBER:
				{
				setState(285);
				match(EXPRESSION_NUMBER);
				}
				break;
			case EXPRESSION_STRING:
				{
				setState(286);
				match(EXPRESSION_STRING);
				}
				break;
			case EXPRESSION_VAR:
				{
				setState(287);
				exepression_var();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Right_expressionContext extends ParserRuleContext {
		public TerminalNode EXPRESSION_NUMBER() { return getToken(HTMLPHPPARSER.EXPRESSION_NUMBER, 0); }
		public TerminalNode EXPRESSION_STRING() { return getToken(HTMLPHPPARSER.EXPRESSION_STRING, 0); }
		public Exepression_varContext exepression_var() {
			return getRuleContext(Exepression_varContext.class,0);
		}
		public Right_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_right_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterRight_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitRight_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitRight_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Right_expressionContext right_expression() throws RecognitionException {
		Right_expressionContext _localctx = new Right_expressionContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_right_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(293);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case EXPRESSION_NUMBER:
				{
				setState(290);
				match(EXPRESSION_NUMBER);
				}
				break;
			case EXPRESSION_STRING:
				{
				setState(291);
				match(EXPRESSION_STRING);
				}
				break;
			case EXPRESSION_VAR:
				{
				setState(292);
				exepression_var();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Exepression_varContext extends ParserRuleContext {
		public TerminalNode EXPRESSION_VAR() { return getToken(HTMLPHPPARSER.EXPRESSION_VAR, 0); }
		public List<Array_boundsContext> array_bounds() {
			return getRuleContexts(Array_boundsContext.class);
		}
		public Array_boundsContext array_bounds(int i) {
			return getRuleContext(Array_boundsContext.class,i);
		}
		public Exepression_varContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exepression_var; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterExepression_var(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitExepression_var(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitExepression_var(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Exepression_varContext exepression_var() throws RecognitionException {
		Exepression_varContext _localctx = new Exepression_varContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_exepression_var);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(295);
			match(EXPRESSION_VAR);
			setState(299);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 26)) & ~0x3f) == 0 && ((1L << (_la - 26)) & ((1L << (TO_LOWER_ARRAY_OPEN_BRACKETS - 26)) | (1L << (TO_UPPER_ARRAY_OPEN_BRACKETS - 26)) | (1L << (ADD_VAR_ARRAY_OPEN_BRACKETS - 26)) | (1L << (EXPRESSION_ARRAY_OPEN_BRACKETS - 26)) | (1L << (FOR_EXPRESSION_ARRAY_VAR_OPEN_BREACKETS - 26)))) != 0)) {
				{
				{
				setState(296);
				array_bounds();
				}
				}
				setState(301);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Exepression_operatorContext extends ParserRuleContext {
		public TerminalNode AND_AND_OPERATOR() { return getToken(HTMLPHPPARSER.AND_AND_OPERATOR, 0); }
		public TerminalNode OR_OPERATOR() { return getToken(HTMLPHPPARSER.OR_OPERATOR, 0); }
		public Exepression_operatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exepression_operator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterExepression_operator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitExepression_operator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitExepression_operator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Exepression_operatorContext exepression_operator() throws RecognitionException {
		Exepression_operatorContext _localctx = new Exepression_operatorContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_exepression_operator);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(302);
			_la = _input.LA(1);
			if ( !(_la==AND_AND_OPERATOR || _la==OR_OPERATOR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OpertatorContext extends ParserRuleContext {
		public TerminalNode BIGGER_OPERATOR() { return getToken(HTMLPHPPARSER.BIGGER_OPERATOR, 0); }
		public TerminalNode SMALLER_OPERATOR() { return getToken(HTMLPHPPARSER.SMALLER_OPERATOR, 0); }
		public TerminalNode BIGGER_AND_EQUALS_OPERATOR() { return getToken(HTMLPHPPARSER.BIGGER_AND_EQUALS_OPERATOR, 0); }
		public TerminalNode SMALLER_AND_EQUALS_OPERATOR() { return getToken(HTMLPHPPARSER.SMALLER_AND_EQUALS_OPERATOR, 0); }
		public TerminalNode EQUALS_OPERATOR() { return getToken(HTMLPHPPARSER.EQUALS_OPERATOR, 0); }
		public OpertatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_opertator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterOpertator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitOpertator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitOpertator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OpertatorContext opertator() throws RecognitionException {
		OpertatorContext _localctx = new OpertatorContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_opertator);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(304);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << BIGGER_OPERATOR) | (1L << SMALLER_OPERATOR) | (1L << BIGGER_AND_EQUALS_OPERATOR) | (1L << SMALLER_AND_EQUALS_OPERATOR) | (1L << EQUALS_OPERATOR))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Array_boundsContext extends ParserRuleContext {
		public TerminalNode EXPRESSION_ARRAY_OPEN_BRACKETS() { return getToken(HTMLPHPPARSER.EXPRESSION_ARRAY_OPEN_BRACKETS, 0); }
		public TerminalNode FOR_EXPRESSION_ARRAY_VAR_OPEN_BREACKETS() { return getToken(HTMLPHPPARSER.FOR_EXPRESSION_ARRAY_VAR_OPEN_BREACKETS, 0); }
		public TerminalNode ADD_VAR_ARRAY_OPEN_BRACKETS() { return getToken(HTMLPHPPARSER.ADD_VAR_ARRAY_OPEN_BRACKETS, 0); }
		public TerminalNode TO_LOWER_ARRAY_OPEN_BRACKETS() { return getToken(HTMLPHPPARSER.TO_LOWER_ARRAY_OPEN_BRACKETS, 0); }
		public TerminalNode TO_UPPER_ARRAY_OPEN_BRACKETS() { return getToken(HTMLPHPPARSER.TO_UPPER_ARRAY_OPEN_BRACKETS, 0); }
		public TerminalNode ARRAY_INDEX_NUMER() { return getToken(HTMLPHPPARSER.ARRAY_INDEX_NUMER, 0); }
		public TerminalNode ARRAY_INDEX_VAR() { return getToken(HTMLPHPPARSER.ARRAY_INDEX_VAR, 0); }
		public List<TerminalNode> EXPRESSION_ARRAY_CLOSE_BRACKETS() { return getTokens(HTMLPHPPARSER.EXPRESSION_ARRAY_CLOSE_BRACKETS); }
		public TerminalNode EXPRESSION_ARRAY_CLOSE_BRACKETS(int i) {
			return getToken(HTMLPHPPARSER.EXPRESSION_ARRAY_CLOSE_BRACKETS, i);
		}
		public Array_boundsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_array_bounds; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterArray_bounds(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitArray_bounds(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitArray_bounds(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Array_boundsContext array_bounds() throws RecognitionException {
		Array_boundsContext _localctx = new Array_boundsContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_array_bounds);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(306);
			_la = _input.LA(1);
			if ( !(((((_la - 26)) & ~0x3f) == 0 && ((1L << (_la - 26)) & ((1L << (TO_LOWER_ARRAY_OPEN_BRACKETS - 26)) | (1L << (TO_UPPER_ARRAY_OPEN_BRACKETS - 26)) | (1L << (ADD_VAR_ARRAY_OPEN_BRACKETS - 26)) | (1L << (EXPRESSION_ARRAY_OPEN_BRACKETS - 26)) | (1L << (FOR_EXPRESSION_ARRAY_VAR_OPEN_BREACKETS - 26)))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(307);
			_la = _input.LA(1);
			if ( !(_la==ARRAY_INDEX_NUMER || _la==ARRAY_INDEX_VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(311);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==EXPRESSION_ARRAY_CLOSE_BRACKETS) {
				{
				{
				setState(308);
				match(EXPRESSION_ARRAY_CLOSE_BRACKETS);
				}
				}
				setState(313);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InputContext extends ParserRuleContext {
		public TerminalNode IN_ATTR() { return getToken(HTMLPHPPARSER.IN_ATTR, 0); }
		public TerminalNode INPUT_COLON() { return getToken(HTMLPHPPARSER.INPUT_COLON, 0); }
		public TerminalNode INPUT_SIMICOLON() { return getToken(HTMLPHPPARSER.INPUT_SIMICOLON, 0); }
		public FieldContext field() {
			return getRuleContext(FieldContext.class,0);
		}
		public Multiple_choice_fieldContext multiple_choice_field() {
			return getRuleContext(Multiple_choice_fieldContext.class,0);
		}
		public FileContext file() {
			return getRuleContext(FileContext.class,0);
		}
		public LocationContext location() {
			return getRuleContext(LocationContext.class,0);
		}
		public InputContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_input; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterInput(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitInput(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitInput(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InputContext input() throws RecognitionException {
		InputContext _localctx = new InputContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_input);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(314);
			match(IN_ATTR);
			setState(315);
			match(INPUT_COLON);
			setState(319);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case FIELD:
				{
				setState(316);
				field();
				}
				break;
			case CHECKBOX:
			case DROPDOWN:
			case RADIO:
				{
				setState(317);
				multiple_choice_field();
				}
				break;
			case FILE:
				{
				setState(318);
				file();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(321);
			match(INPUT_SIMICOLON);
			setState(323);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LOCATION) {
				{
				setState(322);
				location();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OutputContext extends ParserRuleContext {
		public TerminalNode OUT_ATT() { return getToken(HTMLPHPPARSER.OUT_ATT, 0); }
		public TerminalNode OUTPUT_COLON() { return getToken(HTMLPHPPARSER.OUTPUT_COLON, 0); }
		public TerminalNode OUTPUT_SIMICOLON() { return getToken(HTMLPHPPARSER.OUTPUT_SIMICOLON, 0); }
		public OutputTextContext outputText() {
			return getRuleContext(OutputTextContext.class,0);
		}
		public ImageContext image() {
			return getRuleContext(ImageContext.class,0);
		}
		public LocationContext location() {
			return getRuleContext(LocationContext.class,0);
		}
		public OutputContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_output; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterOutput(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitOutput(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitOutput(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OutputContext output() throws RecognitionException {
		OutputContext _localctx = new OutputContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_output);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(325);
			match(OUT_ATT);
			setState(326);
			match(OUTPUT_COLON);
			setState(329);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case OUT_TEXT:
				{
				setState(327);
				outputText();
				}
				break;
			case OUT_IMAGE:
				{
				setState(328);
				image();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(331);
			match(OUTPUT_SIMICOLON);
			setState(333);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LOCATION) {
				{
				setState(332);
				location();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FieldContext extends ParserRuleContext {
		public TerminalNode FIELD() { return getToken(HTMLPHPPARSER.FIELD, 0); }
		public TerminalNode INPUT_FIELD_OPEN_ARCH() { return getToken(HTMLPHPPARSER.INPUT_FIELD_OPEN_ARCH, 0); }
		public TerminalNode INPUT_FIELD() { return getToken(HTMLPHPPARSER.INPUT_FIELD, 0); }
		public TerminalNode INPUT_FIELD_CLOSE_ARCH() { return getToken(HTMLPHPPARSER.INPUT_FIELD_CLOSE_ARCH, 0); }
		public FieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FieldContext field() throws RecognitionException {
		FieldContext _localctx = new FieldContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_field);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(335);
			match(FIELD);
			setState(336);
			match(INPUT_FIELD_OPEN_ARCH);
			setState(337);
			match(INPUT_FIELD);
			setState(338);
			match(INPUT_FIELD_CLOSE_ARCH);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FileContext extends ParserRuleContext {
		public TerminalNode FILE() { return getToken(HTMLPHPPARSER.FILE, 0); }
		public TerminalNode INPUT_CHOCIE_OPEN_ARCH() { return getToken(HTMLPHPPARSER.INPUT_CHOCIE_OPEN_ARCH, 0); }
		public TerminalNode CHOICE_NAME() { return getToken(HTMLPHPPARSER.CHOICE_NAME, 0); }
		public TerminalNode INPUT_CHOICE_COMMA() { return getToken(HTMLPHPPARSER.INPUT_CHOICE_COMMA, 0); }
		public StringContext string() {
			return getRuleContext(StringContext.class,0);
		}
		public TerminalNode INPUT_CHOICE_CLOSE__ARCH() { return getToken(HTMLPHPPARSER.INPUT_CHOICE_CLOSE__ARCH, 0); }
		public FileContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_file; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterFile(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitFile(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitFile(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FileContext file() throws RecognitionException {
		FileContext _localctx = new FileContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_file);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(340);
			match(FILE);
			setState(341);
			match(INPUT_CHOCIE_OPEN_ARCH);
			setState(342);
			match(CHOICE_NAME);
			setState(343);
			match(INPUT_CHOICE_COMMA);
			setState(344);
			string();
			setState(345);
			match(INPUT_CHOICE_CLOSE__ARCH);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ImageContext extends ParserRuleContext {
		public TerminalNode OUT_IMAGE() { return getToken(HTMLPHPPARSER.OUT_IMAGE, 0); }
		public TerminalNode OUTPUT_IMAGE_OPEN_PARA() { return getToken(HTMLPHPPARSER.OUTPUT_IMAGE_OPEN_PARA, 0); }
		public Image_pathContext image_path() {
			return getRuleContext(Image_pathContext.class,0);
		}
		public TerminalNode OUTPUT_IMAGE_CLOSE_PARA() { return getToken(HTMLPHPPARSER.OUTPUT_IMAGE_CLOSE_PARA, 0); }
		public ImageContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_image; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterImage(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitImage(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitImage(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ImageContext image() throws RecognitionException {
		ImageContext _localctx = new ImageContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_image);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(347);
			match(OUT_IMAGE);
			setState(348);
			match(OUTPUT_IMAGE_OPEN_PARA);
			setState(349);
			image_path();
			setState(350);
			match(OUTPUT_IMAGE_CLOSE_PARA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Multiple_choice_fieldContext extends ParserRuleContext {
		public CheckboxContext checkbox() {
			return getRuleContext(CheckboxContext.class,0);
		}
		public DropdownContext dropdown() {
			return getRuleContext(DropdownContext.class,0);
		}
		public RadioContext radio() {
			return getRuleContext(RadioContext.class,0);
		}
		public Multiple_choice_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_multiple_choice_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterMultiple_choice_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitMultiple_choice_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitMultiple_choice_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Multiple_choice_fieldContext multiple_choice_field() throws RecognitionException {
		Multiple_choice_fieldContext _localctx = new Multiple_choice_fieldContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_multiple_choice_field);
		try {
			setState(355);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CHECKBOX:
				enterOuterAlt(_localctx, 1);
				{
				setState(352);
				checkbox();
				}
				break;
			case DROPDOWN:
				enterOuterAlt(_localctx, 2);
				{
				setState(353);
				dropdown();
				}
				break;
			case RADIO:
				enterOuterAlt(_localctx, 3);
				{
				setState(354);
				radio();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Image_pathContext extends ParserRuleContext {
		public TerminalNode IMAGE_PATH_DOUBLE_QUOTATIONS() { return getToken(HTMLPHPPARSER.IMAGE_PATH_DOUBLE_QUOTATIONS, 0); }
		public TerminalNode DOUBLE_QUOT_INPUT_STRING() { return getToken(HTMLPHPPARSER.DOUBLE_QUOT_INPUT_STRING, 0); }
		public TerminalNode CLOSED_DOUBLE_QUOTATION() { return getToken(HTMLPHPPARSER.CLOSED_DOUBLE_QUOTATION, 0); }
		public Image_pathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_image_path; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterImage_path(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitImage_path(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitImage_path(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Image_pathContext image_path() throws RecognitionException {
		Image_pathContext _localctx = new Image_pathContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_image_path);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(357);
			match(IMAGE_PATH_DOUBLE_QUOTATIONS);
			setState(358);
			match(DOUBLE_QUOT_INPUT_STRING);
			setState(359);
			match(CLOSED_DOUBLE_QUOTATION);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Input_textContext extends ParserRuleContext {
		public StringContext string() {
			return getRuleContext(StringContext.class,0);
		}
		public IntegerContext integer() {
			return getRuleContext(IntegerContext.class,0);
		}
		public Input_textContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_input_text; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterInput_text(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitInput_text(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitInput_text(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Input_textContext input_text() throws RecognitionException {
		Input_textContext _localctx = new Input_textContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_input_text);
		try {
			setState(363);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INPUT_DOUBLE_QUOTATION:
			case INPUT_SINGLE_QUOTATION:
				enterOuterAlt(_localctx, 1);
				{
				setState(361);
				string();
				}
				break;
			case INPUT_NUMBER:
				enterOuterAlt(_localctx, 2);
				{
				setState(362);
				integer();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringContext extends ParserRuleContext {
		public Double_quotations_stringContext double_quotations_string() {
			return getRuleContext(Double_quotations_stringContext.class,0);
		}
		public Single_quotations_stringContext single_quotations_string() {
			return getRuleContext(Single_quotations_stringContext.class,0);
		}
		public StringContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_string; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterString(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitString(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitString(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringContext string() throws RecognitionException {
		StringContext _localctx = new StringContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_string);
		try {
			setState(367);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INPUT_DOUBLE_QUOTATION:
				enterOuterAlt(_localctx, 1);
				{
				setState(365);
				double_quotations_string();
				}
				break;
			case INPUT_SINGLE_QUOTATION:
				enterOuterAlt(_localctx, 2);
				{
				setState(366);
				single_quotations_string();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Double_quotations_stringContext extends ParserRuleContext {
		public TerminalNode INPUT_DOUBLE_QUOTATION() { return getToken(HTMLPHPPARSER.INPUT_DOUBLE_QUOTATION, 0); }
		public TerminalNode DOUBLE_QUOT_INPUT_STRING() { return getToken(HTMLPHPPARSER.DOUBLE_QUOT_INPUT_STRING, 0); }
		public TerminalNode CLOSED_DOUBLE_QUOTATION() { return getToken(HTMLPHPPARSER.CLOSED_DOUBLE_QUOTATION, 0); }
		public Double_quotations_stringContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_double_quotations_string; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterDouble_quotations_string(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitDouble_quotations_string(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitDouble_quotations_string(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Double_quotations_stringContext double_quotations_string() throws RecognitionException {
		Double_quotations_stringContext _localctx = new Double_quotations_stringContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_double_quotations_string);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(369);
			match(INPUT_DOUBLE_QUOTATION);
			setState(370);
			match(DOUBLE_QUOT_INPUT_STRING);
			setState(371);
			match(CLOSED_DOUBLE_QUOTATION);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Single_quotations_stringContext extends ParserRuleContext {
		public TerminalNode INPUT_SINGLE_QUOTATION() { return getToken(HTMLPHPPARSER.INPUT_SINGLE_QUOTATION, 0); }
		public TerminalNode SINGLE_QUOT_INPUT_STRING() { return getToken(HTMLPHPPARSER.SINGLE_QUOT_INPUT_STRING, 0); }
		public TerminalNode CLOSED_SINGLE_QUOTATION() { return getToken(HTMLPHPPARSER.CLOSED_SINGLE_QUOTATION, 0); }
		public Single_quotations_stringContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_single_quotations_string; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterSingle_quotations_string(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitSingle_quotations_string(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitSingle_quotations_string(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Single_quotations_stringContext single_quotations_string() throws RecognitionException {
		Single_quotations_stringContext _localctx = new Single_quotations_stringContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_single_quotations_string);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(373);
			match(INPUT_SINGLE_QUOTATION);
			setState(374);
			match(SINGLE_QUOT_INPUT_STRING);
			setState(375);
			match(CLOSED_SINGLE_QUOTATION);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IntegerContext extends ParserRuleContext {
		public TerminalNode INPUT_NUMBER() { return getToken(HTMLPHPPARSER.INPUT_NUMBER, 0); }
		public IntegerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_integer; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterInteger(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitInteger(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitInteger(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IntegerContext integer() throws RecognitionException {
		IntegerContext _localctx = new IntegerContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_integer);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(377);
			match(INPUT_NUMBER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CheckboxContext extends ParserRuleContext {
		public TerminalNode CHECKBOX() { return getToken(HTMLPHPPARSER.CHECKBOX, 0); }
		public TerminalNode INPUT_CHOCIE_OPEN_ARCH() { return getToken(HTMLPHPPARSER.INPUT_CHOCIE_OPEN_ARCH, 0); }
		public TerminalNode CHOICE_NAME() { return getToken(HTMLPHPPARSER.CHOICE_NAME, 0); }
		public List<TerminalNode> INPUT_CHOICE_COMMA() { return getTokens(HTMLPHPPARSER.INPUT_CHOICE_COMMA); }
		public TerminalNode INPUT_CHOICE_COMMA(int i) {
			return getToken(HTMLPHPPARSER.INPUT_CHOICE_COMMA, i);
		}
		public TerminalNode INPUT_CHOICE_CLOSE__ARCH() { return getToken(HTMLPHPPARSER.INPUT_CHOICE_CLOSE__ARCH, 0); }
		public List<Input_textContext> input_text() {
			return getRuleContexts(Input_textContext.class);
		}
		public Input_textContext input_text(int i) {
			return getRuleContext(Input_textContext.class,i);
		}
		public CheckboxContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_checkbox; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterCheckbox(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitCheckbox(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitCheckbox(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CheckboxContext checkbox() throws RecognitionException {
		CheckboxContext _localctx = new CheckboxContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_checkbox);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(379);
			match(CHECKBOX);
			setState(380);
			match(INPUT_CHOCIE_OPEN_ARCH);
			setState(381);
			match(CHOICE_NAME);
			setState(382);
			match(INPUT_CHOICE_COMMA);
			{
			setState(383);
			input_text();
			setState(388);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INPUT_CHOICE_COMMA) {
				{
				{
				setState(384);
				match(INPUT_CHOICE_COMMA);
				setState(385);
				input_text();
				}
				}
				setState(390);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
			setState(391);
			match(INPUT_CHOICE_CLOSE__ARCH);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DropdownContext extends ParserRuleContext {
		public TerminalNode DROPDOWN() { return getToken(HTMLPHPPARSER.DROPDOWN, 0); }
		public TerminalNode INPUT_CHOCIE_OPEN_ARCH() { return getToken(HTMLPHPPARSER.INPUT_CHOCIE_OPEN_ARCH, 0); }
		public TerminalNode CHOICE_NAME() { return getToken(HTMLPHPPARSER.CHOICE_NAME, 0); }
		public List<TerminalNode> INPUT_CHOICE_COMMA() { return getTokens(HTMLPHPPARSER.INPUT_CHOICE_COMMA); }
		public TerminalNode INPUT_CHOICE_COMMA(int i) {
			return getToken(HTMLPHPPARSER.INPUT_CHOICE_COMMA, i);
		}
		public TerminalNode INPUT_CHOICE_CLOSE__ARCH() { return getToken(HTMLPHPPARSER.INPUT_CHOICE_CLOSE__ARCH, 0); }
		public List<Input_textContext> input_text() {
			return getRuleContexts(Input_textContext.class);
		}
		public Input_textContext input_text(int i) {
			return getRuleContext(Input_textContext.class,i);
		}
		public DropdownContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dropdown; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterDropdown(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitDropdown(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitDropdown(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DropdownContext dropdown() throws RecognitionException {
		DropdownContext _localctx = new DropdownContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_dropdown);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(393);
			match(DROPDOWN);
			setState(394);
			match(INPUT_CHOCIE_OPEN_ARCH);
			setState(395);
			match(CHOICE_NAME);
			setState(396);
			match(INPUT_CHOICE_COMMA);
			{
			setState(397);
			input_text();
			setState(402);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INPUT_CHOICE_COMMA) {
				{
				{
				setState(398);
				match(INPUT_CHOICE_COMMA);
				setState(399);
				input_text();
				}
				}
				setState(404);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
			setState(405);
			match(INPUT_CHOICE_CLOSE__ARCH);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RadioContext extends ParserRuleContext {
		public TerminalNode RADIO() { return getToken(HTMLPHPPARSER.RADIO, 0); }
		public TerminalNode INPUT_CHOCIE_OPEN_ARCH() { return getToken(HTMLPHPPARSER.INPUT_CHOCIE_OPEN_ARCH, 0); }
		public TerminalNode CHOICE_NAME() { return getToken(HTMLPHPPARSER.CHOICE_NAME, 0); }
		public List<TerminalNode> INPUT_CHOICE_COMMA() { return getTokens(HTMLPHPPARSER.INPUT_CHOICE_COMMA); }
		public TerminalNode INPUT_CHOICE_COMMA(int i) {
			return getToken(HTMLPHPPARSER.INPUT_CHOICE_COMMA, i);
		}
		public TerminalNode INPUT_CHOICE_CLOSE__ARCH() { return getToken(HTMLPHPPARSER.INPUT_CHOICE_CLOSE__ARCH, 0); }
		public List<Input_textContext> input_text() {
			return getRuleContexts(Input_textContext.class);
		}
		public Input_textContext input_text(int i) {
			return getRuleContext(Input_textContext.class,i);
		}
		public RadioContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_radio; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterRadio(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitRadio(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitRadio(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RadioContext radio() throws RecognitionException {
		RadioContext _localctx = new RadioContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_radio);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(407);
			match(RADIO);
			setState(408);
			match(INPUT_CHOCIE_OPEN_ARCH);
			setState(409);
			match(CHOICE_NAME);
			setState(410);
			match(INPUT_CHOICE_COMMA);
			{
			setState(411);
			input_text();
			setState(412);
			match(INPUT_CHOICE_COMMA);
			setState(413);
			input_text();
			}
			setState(415);
			match(INPUT_CHOICE_CLOSE__ARCH);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OutputTextContext extends ParserRuleContext {
		public TerminalNode OUT_TEXT() { return getToken(HTMLPHPPARSER.OUT_TEXT, 0); }
		public TerminalNode OUTPUT_PARAM_OPEN_PARA() { return getToken(HTMLPHPPARSER.OUTPUT_PARAM_OPEN_PARA, 0); }
		public TerminalNode OUTPUT_TEXT() { return getToken(HTMLPHPPARSER.OUTPUT_TEXT, 0); }
		public TerminalNode OUTPUT_PARAM_CLOSE_PARA() { return getToken(HTMLPHPPARSER.OUTPUT_PARAM_CLOSE_PARA, 0); }
		public OutputTextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_outputText; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).enterOutputText(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HTMLPHPPARSERListener ) ((HTMLPHPPARSERListener)listener).exitOutputText(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HTMLPHPPARSERVisitor ) return ((HTMLPHPPARSERVisitor<? extends T>)visitor).visitOutputText(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OutputTextContext outputText() throws RecognitionException {
		OutputTextContext _localctx = new OutputTextContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_outputText);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(417);
			match(OUT_TEXT);
			setState(418);
			match(OUTPUT_PARAM_OPEN_PARA);
			setState(419);
			match(OUTPUT_TEXT);
			setState(420);
			match(OUTPUT_PARAM_CLOSE_PARA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\u0083\u01a9\4\2\t"+
		"\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \4!"+
		"\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\4&\t&\4\'\t\'\4(\t(\4)\t)\4*\t*\4+\t+\4"+
		",\t,\3\2\6\2Z\n\2\r\2\16\2[\3\2\6\2_\n\2\r\2\16\2`\3\3\3\3\3\3\3\3\5\3"+
		"g\n\3\3\3\3\3\7\3k\n\3\f\3\16\3n\13\3\3\3\3\3\3\3\3\4\3\4\3\4\3\4\3\4"+
		"\3\4\3\5\3\5\3\5\3\6\3\6\5\6~\n\6\3\7\3\7\7\7\u0082\n\7\f\7\16\7\u0085"+
		"\13\7\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\b\3\t\3\t\3\t\3\t\3\t\5\t\u0094\n"+
		"\t\3\n\3\n\3\n\3\n\3\n\3\n\7\n\u009c\n\n\f\n\16\n\u009f\13\n\3\n\3\n\7"+
		"\n\u00a3\n\n\f\n\16\n\u00a6\13\n\3\n\5\n\u00a9\n\n\3\13\3\13\3\13\3\13"+
		"\3\13\3\13\7\13\u00b1\n\13\f\13\16\13\u00b4\13\13\3\13\3\13\3\f\3\f\3"+
		"\f\7\f\u00bb\n\f\f\f\16\f\u00be\13\f\3\f\3\f\3\r\3\r\3\r\3\r\3\r\3\r\5"+
		"\r\u00c8\n\r\6\r\u00ca\n\r\r\r\16\r\u00cb\3\r\3\r\3\16\3\16\3\17\3\17"+
		"\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\7\17\u00df\n\17"+
		"\f\17\16\17\u00e2\13\17\3\17\3\17\3\20\3\20\7\20\u00e8\n\20\f\20\16\20"+
		"\u00eb\13\20\3\20\5\20\u00ee\n\20\3\21\3\21\3\21\5\21\u00f3\n\21\3\22"+
		"\3\22\3\22\7\22\u00f8\n\22\f\22\16\22\u00fb\13\22\3\22\3\22\3\22\3\22"+
		"\3\23\3\23\3\23\7\23\u0104\n\23\f\23\16\23\u0107\13\23\3\23\3\23\3\24"+
		"\3\24\3\24\7\24\u010e\n\24\f\24\16\24\u0111\13\24\3\24\3\24\3\25\3\25"+
		"\3\25\3\26\3\26\3\26\3\26\3\26\3\26\5\26\u011e\n\26\3\27\3\27\3\27\5\27"+
		"\u0123\n\27\3\30\3\30\3\30\5\30\u0128\n\30\3\31\3\31\7\31\u012c\n\31\f"+
		"\31\16\31\u012f\13\31\3\32\3\32\3\33\3\33\3\34\3\34\3\34\7\34\u0138\n"+
		"\34\f\34\16\34\u013b\13\34\3\35\3\35\3\35\3\35\3\35\5\35\u0142\n\35\3"+
		"\35\3\35\5\35\u0146\n\35\3\36\3\36\3\36\3\36\5\36\u014c\n\36\3\36\3\36"+
		"\5\36\u0150\n\36\3\37\3\37\3\37\3\37\3\37\3 \3 \3 \3 \3 \3 \3 \3!\3!\3"+
		"!\3!\3!\3\"\3\"\3\"\5\"\u0166\n\"\3#\3#\3#\3#\3$\3$\5$\u016e\n$\3%\3%"+
		"\5%\u0172\n%\3&\3&\3&\3&\3\'\3\'\3\'\3\'\3(\3(\3)\3)\3)\3)\3)\3)\3)\7"+
		")\u0185\n)\f)\16)\u0188\13)\3)\3)\3*\3*\3*\3*\3*\3*\3*\7*\u0193\n*\f*"+
		"\16*\u0196\13*\3*\3*\3+\3+\3+\3+\3+\3+\3+\3+\3+\3+\3,\3,\3,\3,\3,\3,\2"+
		"\2-\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,.\60\62\64\668:<>@B"+
		"DFHJLNPRTV\2\b\3\2~\u0082\3\2.\60\3\2:;\3\2<@\7\2\34\34  ##DDNN\3\2FG"+
		"\2\u01a8\2Y\3\2\2\2\4b\3\2\2\2\6r\3\2\2\2\bx\3\2\2\2\n}\3\2\2\2\f\177"+
		"\3\2\2\2\16\u0089\3\2\2\2\20\u0093\3\2\2\2\22\u0095\3\2\2\2\24\u00aa\3"+
		"\2\2\2\26\u00b7\3\2\2\2\30\u00c1\3\2\2\2\32\u00cf\3\2\2\2\34\u00d1\3\2"+
		"\2\2\36\u00ed\3\2\2\2 \u00f2\3\2\2\2\"\u00f4\3\2\2\2$\u0100\3\2\2\2&\u010a"+
		"\3\2\2\2(\u0114\3\2\2\2*\u0117\3\2\2\2,\u0122\3\2\2\2.\u0127\3\2\2\2\60"+
		"\u0129\3\2\2\2\62\u0130\3\2\2\2\64\u0132\3\2\2\2\66\u0134\3\2\2\28\u013c"+
		"\3\2\2\2:\u0147\3\2\2\2<\u0151\3\2\2\2>\u0156\3\2\2\2@\u015d\3\2\2\2B"+
		"\u0165\3\2\2\2D\u0167\3\2\2\2F\u016d\3\2\2\2H\u0171\3\2\2\2J\u0173\3\2"+
		"\2\2L\u0177\3\2\2\2N\u017b\3\2\2\2P\u017d\3\2\2\2R\u018b\3\2\2\2T\u0199"+
		"\3\2\2\2V\u01a3\3\2\2\2XZ\5\4\3\2YX\3\2\2\2Z[\3\2\2\2[Y\3\2\2\2[\\\3\2"+
		"\2\2\\^\3\2\2\2]_\5\6\4\2^]\3\2\2\2_`\3\2\2\2`^\3\2\2\2`a\3\2\2\2a\3\3"+
		"\2\2\2bc\7\5\2\2cf\7\b\2\2de\7\7\2\2eg\7\b\2\2fd\3\2\2\2fg\3\2\2\2gh\3"+
		"\2\2\2hl\7\t\2\2ik\5\n\6\2ji\3\2\2\2kn\3\2\2\2lj\3\2\2\2lm\3\2\2\2mo\3"+
		"\2\2\2nl\3\2\2\2op\5\b\5\2pq\7W\2\2q\5\3\2\2\2rs\7\4\2\2st\7\f\2\2tu\7"+
		"\13\2\2uv\7\f\2\2vw\5\f\7\2w\7\3\2\2\2xy\7V\2\2yz\5\16\b\2z\t\3\2\2\2"+
		"{~\58\35\2|~\5:\36\2}{\3\2\2\2}|\3\2\2\2~\13\3\2\2\2\177\u0083\7\r\2\2"+
		"\u0080\u0082\5\20\t\2\u0081\u0080\3\2\2\2\u0082\u0085\3\2\2\2\u0083\u0081"+
		"\3\2\2\2\u0083\u0084\3\2\2\2\u0084\u0086\3\2\2\2\u0085\u0083\3\2\2\2\u0086"+
		"\u0087\7\20\2\2\u0087\u0088\7\16\2\2\u0088\r\3\2\2\2\u0089\u008a\7U\2"+
		"\2\u008a\u008b\7}\2\2\u008b\u008c\t\2\2\2\u008c\u008d\7\u0083\2\2\u008d"+
		"\17\3\2\2\2\u008e\u0094\5\30\r\2\u008f\u0094\5\22\n\2\u0090\u0094\5\34"+
		"\17\2\u0091\u0094\5 \21\2\u0092\u0094\5(\25\2\u0093\u008e\3\2\2\2\u0093"+
		"\u008f\3\2\2\2\u0093\u0090\3\2\2\2\u0093\u0091\3\2\2\2\u0093\u0092\3\2"+
		"\2\2\u0094\21\3\2\2\2\u0095\u0096\7\21\2\2\u0096\u0097\7\64\2\2\u0097"+
		"\u0098\5*\26\2\u0098\u0099\7E\2\2\u0099\u009d\7\65\2\2\u009a\u009c\5\20"+
		"\t\2\u009b\u009a\3\2\2\2\u009c\u009f\3\2\2\2\u009d\u009b\3\2\2\2\u009d"+
		"\u009e\3\2\2\2\u009e\u00a0\3\2\2\2\u009f\u009d\3\2\2\2\u00a0\u00a4\7\20"+
		"\2\2\u00a1\u00a3\5\24\13\2\u00a2\u00a1\3\2\2\2\u00a3\u00a6\3\2\2\2\u00a4"+
		"\u00a2\3\2\2\2\u00a4\u00a5\3\2\2\2\u00a5\u00a8\3\2\2\2\u00a6\u00a4\3\2"+
		"\2\2\u00a7\u00a9\5\26\f\2\u00a8\u00a7\3\2\2\2\u00a8\u00a9\3\2\2\2\u00a9"+
		"\23\3\2\2\2\u00aa\u00ab\7\22\2\2\u00ab\u00ac\7\64\2\2\u00ac\u00ad\5*\26"+
		"\2\u00ad\u00ae\7E\2\2\u00ae\u00b2\7\65\2\2\u00af\u00b1\5\20\t\2\u00b0"+
		"\u00af\3\2\2\2\u00b1\u00b4\3\2\2\2\u00b2\u00b0\3\2\2\2\u00b2\u00b3\3\2"+
		"\2\2\u00b3\u00b5\3\2\2\2\u00b4\u00b2\3\2\2\2\u00b5\u00b6\7\20\2\2\u00b6"+
		"\25\3\2\2\2\u00b7\u00b8\7\23\2\2\u00b8\u00bc\7\65\2\2\u00b9\u00bb\5\20"+
		"\t\2\u00ba\u00b9\3\2\2\2\u00bb\u00be\3\2\2\2\u00bc\u00ba\3\2\2\2\u00bc"+
		"\u00bd\3\2\2\2\u00bd\u00bf\3\2\2\2\u00be\u00bc\3\2\2\2\u00bf\u00c0\7\20"+
		"\2\2\u00c0\27\3\2\2\2\u00c1\u00c2\7\25\2\2\u00c2\u00c3\7(\2\2\u00c3\u00c4"+
		"\7*\2\2\u00c4\u00c9\7,\2\2\u00c5\u00c7\5\32\16\2\u00c6\u00c8\7+\2\2\u00c7"+
		"\u00c6\3\2\2\2\u00c7\u00c8\3\2\2\2\u00c8\u00ca\3\2\2\2\u00c9\u00c5\3\2"+
		"\2\2\u00ca\u00cb\3\2\2\2\u00cb\u00c9\3\2\2\2\u00cb\u00cc\3\2\2\2\u00cc"+
		"\u00cd\3\2\2\2\u00cd\u00ce\7-\2\2\u00ce\31\3\2\2\2\u00cf\u00d0\t\3\2\2"+
		"\u00d0\33\3\2\2\2\u00d1\u00d2\7\24\2\2\u00d2\u00d3\7\66\2\2\u00d3\u00d4"+
		"\7L\2\2\u00d4\u00d5\7K\2\2\u00d5\u00d6\7J\2\2\u00d6\u00d7\7P\2\2\u00d7"+
		"\u00d8\5\36\20\2\u00d8\u00d9\7Q\2\2\u00d9\u00da\5\36\20\2\u00da\u00db"+
		"\7O\2\2\u00db\u00dc\7\67\2\2\u00dc\u00e0\78\2\2\u00dd\u00df\5\20\t\2\u00de"+
		"\u00dd\3\2\2\2\u00df\u00e2\3\2\2\2\u00e0\u00de\3\2\2\2\u00e0\u00e1\3\2"+
		"\2\2\u00e1\u00e3\3\2\2\2\u00e2\u00e0\3\2\2\2\u00e3\u00e4\7\20\2\2\u00e4"+
		"\35\3\2\2\2\u00e5\u00e9\7L\2\2\u00e6\u00e8\5\66\34\2\u00e7\u00e6\3\2\2"+
		"\2\u00e8\u00eb\3\2\2\2\u00e9\u00e7\3\2\2\2\u00e9\u00ea\3\2\2\2\u00ea\u00ee"+
		"\3\2\2\2\u00eb\u00e9\3\2\2\2\u00ec\u00ee\7M\2\2\u00ed\u00e5\3\2\2\2\u00ed"+
		"\u00ec\3\2\2\2\u00ee\37\3\2\2\2\u00ef\u00f3\5\"\22\2\u00f0\u00f3\5$\23"+
		"\2\u00f1\u00f3\5&\24\2\u00f2\u00ef\3\2\2\2\u00f2\u00f0\3\2\2\2\u00f2\u00f1"+
		"\3\2\2\2\u00f3!\3\2\2\2\u00f4\u00f5\7\26\2\2\u00f5\u00f9\7\"\2\2\u00f6"+
		"\u00f8\5\66\34\2\u00f7\u00f6\3\2\2\2\u00f8\u00fb\3\2\2\2\u00f9\u00f7\3"+
		"\2\2\2\u00f9\u00fa\3\2\2\2\u00fa\u00fc\3\2\2\2\u00fb\u00f9\3\2\2\2\u00fc"+
		"\u00fd\7%\2\2\u00fd\u00fe\7$\2\2\u00fe\u00ff\7&\2\2\u00ff#\3\2\2\2\u0100"+
		"\u0101\7\27\2\2\u0101\u0105\7\33\2\2\u0102\u0104\5\66\34\2\u0103\u0102"+
		"\3\2\2\2\u0104\u0107\3\2\2\2\u0105\u0103\3\2\2\2\u0105\u0106\3\2\2\2\u0106"+
		"\u0108\3\2\2\2\u0107\u0105\3\2\2\2\u0108\u0109\7\35\2\2\u0109%\3\2\2\2"+
		"\u010a\u010b\7\30\2\2\u010b\u010f\7\37\2\2\u010c\u010e\5\66\34\2\u010d"+
		"\u010c\3\2\2\2\u010e\u0111\3\2\2\2\u010f\u010d\3\2\2\2\u010f\u0110\3\2"+
		"\2\2\u0110\u0112\3\2\2\2\u0111\u010f\3\2\2\2\u0112\u0113\7!\2\2\u0113"+
		"\'\3\2\2\2\u0114\u0115\7\31\2\2\u0115\u0116\7\61\2\2\u0116)\3\2\2\2\u0117"+
		"\u0118\5,\27\2\u0118\u0119\5\64\33\2\u0119\u011d\5.\30\2\u011a\u011b\5"+
		"\62\32\2\u011b\u011c\5*\26\2\u011c\u011e\3\2\2\2\u011d\u011a\3\2\2\2\u011d"+
		"\u011e\3\2\2\2\u011e+\3\2\2\2\u011f\u0123\7B\2\2\u0120\u0123\7C\2\2\u0121"+
		"\u0123\5\60\31\2\u0122\u011f\3\2\2\2\u0122\u0120\3\2\2\2\u0122\u0121\3"+
		"\2\2\2\u0123-\3\2\2\2\u0124\u0128\7B\2\2\u0125\u0128\7C\2\2\u0126\u0128"+
		"\5\60\31\2\u0127\u0124\3\2\2\2\u0127\u0125\3\2\2\2\u0127\u0126\3\2\2\2"+
		"\u0128/\3\2\2\2\u0129\u012d\7A\2\2\u012a\u012c\5\66\34\2\u012b\u012a\3"+
		"\2\2\2\u012c\u012f\3\2\2\2\u012d\u012b\3\2\2\2\u012d\u012e\3\2\2\2\u012e"+
		"\61\3\2\2\2\u012f\u012d\3\2\2\2\u0130\u0131\t\4\2\2\u0131\63\3\2\2\2\u0132"+
		"\u0133\t\5\2\2\u0133\65\3\2\2\2\u0134\u0135\t\6\2\2\u0135\u0139\t\7\2"+
		"\2\u0136\u0138\7H\2\2\u0137\u0136\3\2\2\2\u0138\u013b\3\2\2\2\u0139\u0137"+
		"\3\2\2\2\u0139\u013a\3\2\2\2\u013a\67\3\2\2\2\u013b\u0139\3\2\2\2\u013c"+
		"\u013d\7S\2\2\u013d\u0141\7Y\2\2\u013e\u0142\5<\37\2\u013f\u0142\5B\""+
		"\2\u0140\u0142\5> \2\u0141\u013e\3\2\2\2\u0141\u013f\3\2\2\2\u0141\u0140"+
		"\3\2\2\2\u0142\u0143\3\2\2\2\u0143\u0145\7Z\2\2\u0144\u0146\5\16\b\2\u0145"+
		"\u0144\3\2\2\2\u0145\u0146\3\2\2\2\u01469\3\2\2\2\u0147\u0148\7T\2\2\u0148"+
		"\u014b\7c\2\2\u0149\u014c\5V,\2\u014a\u014c\5@!\2\u014b\u0149\3\2\2\2"+
		"\u014b\u014a\3\2\2\2\u014c\u014d\3\2\2\2\u014d\u014f\7f\2\2\u014e\u0150"+
		"\5\16\b\2\u014f\u014e\3\2\2\2\u014f\u0150\3\2\2\2\u0150;\3\2\2\2\u0151"+
		"\u0152\7[\2\2\u0152\u0153\7g\2\2\u0153\u0154\7h\2\2\u0154\u0155\7i\2\2"+
		"\u0155=\3\2\2\2\u0156\u0157\7_\2\2\u0157\u0158\7l\2\2\u0158\u0159\7k\2"+
		"\2\u0159\u015a\7n\2\2\u015a\u015b\5H%\2\u015b\u015c\7m\2\2\u015c?\3\2"+
		"\2\2\u015d\u015e\7e\2\2\u015e\u015f\7{\2\2\u015f\u0160\5D#\2\u0160\u0161"+
		"\7|\2\2\u0161A\3\2\2\2\u0162\u0166\5P)\2\u0163\u0166\5R*\2\u0164\u0166"+
		"\5T+\2\u0165\u0162\3\2\2\2\u0165\u0163\3\2\2\2\u0165\u0164\3\2\2\2\u0166"+
		"C\3\2\2\2\u0167\u0168\7z\2\2\u0168\u0169\7r\2\2\u0169\u016a\7s\2\2\u016a"+
		"E\3\2\2\2\u016b\u016e\5H%\2\u016c\u016e\5N(\2\u016d\u016b\3\2\2\2\u016d"+
		"\u016c\3\2\2\2\u016eG\3\2\2\2\u016f\u0172\5J&\2\u0170\u0172\5L\'\2\u0171"+
		"\u016f\3\2\2\2\u0171\u0170\3\2\2\2\u0172I\3\2\2\2\u0173\u0174\7o\2\2\u0174"+
		"\u0175\7r\2\2\u0175\u0176\7s\2\2\u0176K\3\2\2\2\u0177\u0178\7p\2\2\u0178"+
		"\u0179\7t\2\2\u0179\u017a\7u\2\2\u017aM\3\2\2\2\u017b\u017c\7q\2\2\u017c"+
		"O\3\2\2\2\u017d\u017e\7\\\2\2\u017e\u017f\7l\2\2\u017f\u0180\7k\2\2\u0180"+
		"\u0181\7n\2\2\u0181\u0186\5F$\2\u0182\u0183\7n\2\2\u0183\u0185\5F$\2\u0184"+
		"\u0182\3\2\2\2\u0185\u0188\3\2\2\2\u0186\u0184\3\2\2\2\u0186\u0187\3\2"+
		"\2\2\u0187\u0189\3\2\2\2\u0188\u0186\3\2\2\2\u0189\u018a\7m\2\2\u018a"+
		"Q\3\2\2\2\u018b\u018c\7]\2\2\u018c\u018d\7l\2\2\u018d\u018e\7k\2\2\u018e"+
		"\u018f\7n\2\2\u018f\u0194\5F$\2\u0190\u0191\7n\2\2\u0191\u0193\5F$\2\u0192"+
		"\u0190\3\2\2\2\u0193\u0196\3\2\2\2\u0194\u0192\3\2\2\2\u0194\u0195\3\2"+
		"\2\2\u0195\u0197\3\2\2\2\u0196\u0194\3\2\2\2\u0197\u0198\7m\2\2\u0198"+
		"S\3\2\2\2\u0199\u019a\7^\2\2\u019a\u019b\7l\2\2\u019b\u019c\7k\2\2\u019c"+
		"\u019d\7n\2\2\u019d\u019e\5F$\2\u019e\u019f\7n\2\2\u019f\u01a0\5F$\2\u01a0"+
		"\u01a1\3\2\2\2\u01a1\u01a2\7m\2\2\u01a2U\3\2\2\2\u01a3\u01a4\7d\2\2\u01a4"+
		"\u01a5\7w\2\2\u01a5\u01a6\7x\2\2\u01a6\u01a7\7y\2\2\u01a7W\3\2\2\2%[`"+
		"fl}\u0083\u0093\u009d\u00a4\u00a8\u00b2\u00bc\u00c7\u00cb\u00e0\u00e9"+
		"\u00ed\u00f2\u00f9\u0105\u010f\u011d\u0122\u0127\u012d\u0139\u0141\u0145"+
		"\u014b\u014f\u0165\u016d\u0171\u0186\u0194";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}